true              &&(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
}());

// Constantes del GDD y de la vista. Ninguna de estas constantes cambia el modelo
// formal: los estados, eventos y matrices viven en src/sed/modelos/.
const CONFIG = {
  TILE_W: 64,
  TILE_H: 32,
  VELOCIDADES: [1, 2, 4],
  SEMILLA: 20261116,

  DURACION_TURNO: 180, // segundos de simulación
  TIEMPOS: {
    llenado: 2.5,
    pasteurizacion: 8,
    enfriamiento: 6,
    embotellado: 4,
    llegadaLeche: 15,
    revisionFallo: 18
  },
  PROBABILIDAD_FALLO: 0.3,
  PUNTOS: {
    botella: 12,
    reparacionPrimerIntento: 20,
    reparacionInvalida: -8,
    desborde: -10,
    intentoBloqueado: -15,
    fallo: -25,
    deadlockEvitado: 30,
    logro: 15,
    deadlock: -100
  },

  VICTORIA: {
    botellasMinimas: 6},

  PALETA: {
    fondo: 0x0b1218,
    suelo: 0x263641,
    sueloAlterno: 0x2d3f4b,
    muro: 0x17232b,
    muroLuz: 0x22323d,
    metal: 0x8fa6b2,
    metalClaro: 0xc7d3da,
    metalOscuro: 0x4c5f6a,
    acento: 0xf2c14e,
    operacion: 0x2e9e5b,
    espera: 0xe0b21b,
    fallo: 0xd64545,
    mantenimiento: 0x3b7dd8,
    frio: 0x7fd1e8,
    leche: 0xf4f1e8,
    vapor: 0xcfeee6,
    lote: 0xe8c07a,
    botella: 0x9be3c0,
    texto: 0xeaf2f5,
    textoSuave: 0x9fb3bf,
    panel: 0x101c24,
    panelBorde: 0x38505e
  },

  COLORES_ESTADO: {
    Vacio: 0x2e9e5b,
    Llenando: 0xe0b21b,
    Pasteurizando: 0xf08a3c,
    Enfriando: 0x7fd1e8,
    Lavado_CIP: 0x3b7dd8,
    Fallo: 0xd64545
  }
};

const PALETA = CONFIG.PALETA;
const COLORES_ESTADO = CONFIG.COLORES_ESTADO;

function hex(color) {
  return `#${color.toString(16).padStart(6, '0')}`;
}

function colorEstado(estado) {
  return COLORES_ESTADO[estado] ?? PALETA.metal;
}

const TILE_W = CONFIG.TILE_W;
const TILE_H = CONFIG.TILE_H;

// Proyección isométrica 2:1 de la guía:
// pantallaX = (x - y) * TILE_W / 2
// pantallaY = (x + y) * TILE_H / 2 - z * TILE_H
function aPantalla(x, y, z = 0) {
  return {
    x: (x - y) * (TILE_W / 2),
    y: (x + y) * (TILE_H / 2) - z * TILE_H
  };
}

function aPantallaConOffset(x, y, z = 0, ox = 480, oy = 100) {
  const p = aPantalla(x, y, z);
  return { x: p.x + ox, y: p.y + oy };
}

// Orden de profundidad: el más cercano (x + y mayor) tapa al lejano.
function profundidad(x, y, z = 0) {
  return (x + y) * 10 + z;
}

// Funciones de dibujo originales, sin imágenes externas. Todas reciben un
// Phaser.GameObjects.Graphics y coordenadas de pantalla ya proyectadas.

const TAU = Math.PI * 2;

function sombra(g, x, y, ancho, alto, alpha = 0.22) {
  g.fillStyle(0x000000, alpha);
  g.fillEllipse(x, y + 3, ancho, alto);
}

function dibujarSuelo(g, celdas = 14, ox = 480, oy = 100) {
  for (let x = 0; x < celdas; x++) {
    for (let y = 0; y < celdas; y++) {
      const color = (x + y) % 2 === 0 ? PALETA.suelo : PALETA.sueloAlterno;
      const pts = [
        aPantalla(x, y),
        aPantalla(x + 1, y),
        aPantalla(x + 1, y + 1),
        aPantalla(x, y + 1)
      ].map((p) => ({ x: p.x + ox, y: p.y + oy }));
      g.fillStyle(color, 1);
      g.fillPoints(pts, true);
      g.lineStyle(1, PALETA.muro, 0.28);
      g.strokePoints(pts, true);
    }
  }
  // borde exterior
  const borde = [
    aPantalla(0, 0),
    aPantalla(celdas, 0),
    aPantalla(celdas, celdas),
    aPantalla(0, celdas)
  ].map((p) => ({ x: p.x + ox, y: p.y + oy }));
  g.lineStyle(2, PALETA.panelBorde, 0.8);
  g.strokePoints(borde, true);
}

function dibujarMuros(g, celdas = 14, ox = 480, oy = 100, alto = 64) {
  for (let i = 0; i < celdas; i++) {
    const a = aPantalla(0, i);
    const b = aPantalla(0, i + 1);
    const pts = [
      { x: a.x + ox, y: a.y + oy },
      { x: b.x + ox, y: b.y + oy },
      { x: b.x + ox, y: b.y + oy - alto },
      { x: a.x + ox, y: a.y + oy - alto }
    ];
    g.fillStyle(i % 2 === 0 ? PALETA.muro : PALETA.muroLuz, 1);
    g.fillPoints(pts, true);
    g.lineStyle(1, PALETA.panelBorde, 0.25);
    g.strokePoints(pts, true);
  }
  for (let i = 0; i < celdas; i++) {
    const a = aPantalla(i, 0);
    const b = aPantalla(i + 1, 0);
    const pts = [
      { x: a.x + ox, y: a.y + oy },
      { x: b.x + ox, y: b.y + oy },
      { x: b.x + ox, y: b.y + oy - alto },
      { x: a.x + ox, y: a.y + oy - alto }
    ];
    g.fillStyle(i % 2 === 0 ? PALETA.muroLuz : PALETA.muro, 1);
    g.fillPoints(pts, true);
    g.lineStyle(1, PALETA.panelBorde, 0.25);
    g.strokePoints(pts, true);
  }
}

function dibujarSilo(g, x, y, cantidad = 6, k = 10) {
  const nivel = Math.max(0, Math.min(1, cantidad / Math.max(1, k)));
  sombra(g, x, y, 104, 28, 0.28);
  g.fillStyle(PALETA.metalOscuro, 1);
  g.fillRoundedRect(x - 38, y - 152, 76, 148, 10);
  g.fillStyle(PALETA.metal, 1);
  g.fillRoundedRect(x - 34, y - 150, 68, 144, 9);
  g.fillStyle(PALETA.metalClaro, 0.35);
  g.fillRoundedRect(x - 30, y - 146, 12, 136, 6);
  // leche
  const altoLeche = 122 * nivel;
  if (altoLeche > 2) {
    g.fillStyle(PALETA.leche, 0.88);
    g.fillRoundedRect(x - 25, y - 14 - altoLeche, 50, altoLeche, 6);
    g.fillStyle(0xffffff, 0.35);
    g.fillEllipse(x, y - 14 - altoLeche, 50, 12);
  }
  // ventana y bandas
  g.lineStyle(2, PALETA.panelBorde, 0.9);
  g.strokeRoundedRect(x - 27, y - 142, 54, 126, 7);
  g.lineStyle(3, PALETA.metalOscuro, 0.9);
  g.lineBetween(x - 36, y - 116, x + 36, y - 116);
  g.lineBetween(x - 36, y - 62, x + 36, y - 62);
  g.lineBetween(x - 36, y - 26, x + 36, y - 26);
  // tapa
  g.fillStyle(PALETA.metalClaro, 1);
  g.fillEllipse(x, y - 152, 76, 24);
  g.lineStyle(2, PALETA.metalOscuro, 0.9);
  g.strokeEllipse(x, y - 152, 76, 24);
  // escalera
  g.lineStyle(2, PALETA.metalClaro, 0.75);
  g.lineBetween(x + 30, y - 132, x + 30, y - 10);
  g.lineBetween(x + 40, y - 132, x + 40, y - 10);
  for (let i = 0; i < 7; i++) {
    g.lineBetween(x + 30, y - 124 + i * 17, x + 40, y - 124 + i * 17);
  }
  // tubo superior
  g.lineStyle(6, PALETA.metalClaro, 0.8);
  g.lineBetween(x + 30, y - 150, x + 30, y - 170);
}

function dibujarTanque(g, x, y, estado = 'Vacio', nivel = 0.2, seleccionado = false) {
  const color = COLORES_ESTADO[estado] ?? PALETA.metal;
  sombra(g, x, y, 90, 24, 0.26);
  if (seleccionado) {
    for (let i = 3; i >= 1; i--) {
      g.fillStyle(color, 0.06 * i);
      g.fillEllipse(x, y - 46, 100 + i * 14, 120 + i * 8);
    }
  }
  // cuerpo
  g.fillStyle(PALETA.metalOscuro, 1);
  g.fillRoundedRect(x - 38, y - 90, 76, 86, 10);
  g.fillStyle(PALETA.metal, 1);
  g.fillRoundedRect(x - 34, y - 88, 68, 82, 9);
  g.fillStyle(PALETA.metalClaro, 0.4);
  g.fillRoundedRect(x - 30, y - 84, 11, 74, 5);
  // ventana
  const alto = 62 * Math.max(0.05, Math.min(1, nivel));
  const colorLiquido =
    estado === 'Enfriando' ? PALETA.frio :
    estado === 'Lavado_CIP' ? PALETA.mantenimiento :
    estado === 'Fallo' ? PALETA.fallo :
    PALETA.leche;
  g.fillStyle(colorLiquido, estado === 'Vacio' ? 0.3 : 0.88);
  g.fillRoundedRect(x - 23, y - 17 - alto, 46, alto, 5);
  g.fillStyle(0xffffff, 0.25);
  g.fillEllipse(x, y - 17 - alto, 46, 10);
  g.lineStyle(2, PALETA.panelBorde, 0.9);
  g.strokeRoundedRect(x - 25, y - 80, 50, 64, 6);
  // tapa y bandas
  g.fillStyle(PALETA.metalClaro, 1);
  g.fillEllipse(x, y - 90, 76, 24);
  g.lineStyle(2, PALETA.metalOscuro, 0.9);
  g.strokeEllipse(x, y - 90, 76, 24);
  g.lineStyle(3, PALETA.metalOscuro, 0.85);
  g.lineBetween(x - 36, y - 70, x + 36, y - 70);
  g.lineBetween(x - 36, y - 24, x + 36, y - 24);
  // aro de estado
  g.lineStyle(3, color, 0.95);
  g.strokeEllipse(x, y - 5, 88, 26);
  g.fillStyle(color, 0.85);
  g.fillCircle(x + 34, y - 8, 5);
  // tubo
  g.lineStyle(6, PALETA.metalClaro, 0.75);
  g.lineBetween(x - 30, y - 90, x - 30, y - 108);
  dibujarIconoEstado(g, estado, x, y - 116);
}

function dibujarCaldera(g, x, y, activa = true) {
  sombra(g, x, y, 112, 30, 0.28);
  g.fillStyle(PALETA.metalOscuro, 1);
  g.fillRoundedRect(x - 52, y - 58, 104, 50, 10);
  g.fillStyle(PALETA.metal, 1);
  g.fillRoundedRect(x - 47, y - 55, 94, 43, 9);
  g.fillStyle(PALETA.metalClaro, 0.35);
  g.fillRoundedRect(x - 42, y - 51, 14, 35, 5);
  g.fillStyle(PALETA.metalClaro, 1);
  g.fillEllipse(x - 47, y - 34, 18, 42);
  g.fillEllipse(x + 47, y - 34, 18, 42);
  // puerta de fuego
  g.fillStyle(0x2a1c1a, 1);
  g.fillRoundedRect(x + 4, y - 46, 28, 28, 5);
  if (activa) {
    g.fillStyle(0xf08a3c, 0.95);
    g.fillTriangle(x + 10, y - 22, x + 15, y - 43, x + 20, y - 24);
    g.fillStyle(0xf2c14e, 0.95);
    g.fillTriangle(x + 17, y - 22, x + 21, y - 37, x + 26, y - 23);
    g.fillStyle(0xf08a3c, 0.2);
    g.fillCircle(x + 18, y - 32, 22);
  }
  // manómetro
  g.fillStyle(PALETA.metalClaro, 1);
  g.fillCircle(x - 18, y - 24, 8);
  g.lineStyle(2, PALETA.panelBorde, 1);
  g.strokeCircle(x - 18, y - 24, 8);
  g.lineBetween(x - 18, y - 24, x - 14, y - 28);
  // chimenea
  g.fillStyle(PALETA.metalOscuro, 1);
  g.fillRoundedRect(x - 26, y - 86, 14, 32, 3);
  g.fillStyle(PALETA.metal, 1);
  g.fillRoundedRect(x - 28, y - 90, 18, 8, 3);
  g.fillStyle(activa ? PALETA.espera : PALETA.textoSuave, 0.85);
  g.fillCircle(x - 19, y - 92, 3);
}

function dibujarChiller(g, x, y, activa = true) {
  sombra(g, x, y, 104, 28, 0.28);
  // caja isométrica
  const ancho = 88;
  const alto = 66;
  const prof = 28;
  g.fillStyle(PALETA.metalOscuro, 1);
  g.fillPoints([
    { x: x - ancho / 2, y: y - 10 },
    { x: x, y: y - 10 - prof / 2 },
    { x: x + ancho / 2, y: y - 10 },
    { x: x, y: y - 10 + prof / 2 }
  ], true);
  g.fillStyle(PALETA.metal, 1);
  g.fillRect(x - ancho / 2, y - 10 - alto, ancho, alto);
  g.fillStyle(PALETA.metalClaro, 0.28);
  g.fillRect(x - ancho / 2, y - 10 - alto, 14, alto);
  g.fillStyle(PALETA.metalClaro, 1);
  g.fillPoints([
    { x: x - ancho / 2, y: y - 10 - alto },
    { x: x, y: y - 10 - alto - prof / 2 },
    { x: x + ancho / 2, y: y - 10 - alto },
    { x: x, y: y - 10 - alto + prof / 2 }
  ], true);
  // ventilador
  g.fillStyle(PALETA.panel, 1);
  g.fillCircle(x - 18, y - 42, 17);
  g.lineStyle(2, PALETA.metalClaro, 0.8);
  g.strokeCircle(x - 18, y - 42, 17);
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * TAU + 0.4;
    g.lineStyle(3, PALETA.frio, activa ? 0.9 : 0.35);
    g.lineBetween(x - 18, y - 42, x - 18 + Math.cos(a) * 13, y - 42 + Math.sin(a) * 13);
  }
  // serpentín
  g.lineStyle(2, PALETA.frio, activa ? 0.9 : 0.35);
  for (let i = 0; i < 4; i++) {
    g.strokeRoundedRect(x + 8, y - 64 + i * 9, 24, 6, 3);
  }
  // copo
  dibujarIconoEstado(g, 'Enfriando', x + 18, y - 78);
  if (activa) {
    g.fillStyle(PALETA.frio, 0.08);
    g.fillCircle(x, y - 46, 62);
  }
}

function dibujarEmbotelladora(g, x, y, estado = 'Emb_lista') {
  const enMarcha = estado === 'Emb_lista';
  sombra(g, x, y, 150, 30, 0.26);
  // banda
  g.fillStyle(PALETA.metalOscuro, 1);
  g.fillPoints([
    { x: x - 76, y: y - 14 },
    { x: x + 48, y: y - 14 },
    { x: x + 54, y: y - 6 },
    { x: x - 70, y: y - 6 }
  ], true);
  g.fillStyle(PALETA.metal, 1);
  g.fillPoints([
    { x: x - 72, y: y - 18 },
    { x: x + 50, y: y - 18 },
    { x: x + 52, y: y - 12 },
    { x: x - 74, y: y - 12 }
  ], true);
  // botellas sobre la banda
  for (let i = 0; i < 5; i++) {
    dibujarToken(g, 'botella', x - 60 + i * 22, y - 22, 0.8);
  }
  // máquina
  g.fillStyle(PALETA.metalOscuro, 1);
  g.fillRoundedRect(x + 40, y - 76, 44, 70, 7);
  g.fillStyle(PALETA.metal, 1);
  g.fillRoundedRect(x + 44, y - 72, 36, 62, 6);
  g.fillStyle(PALETA.metalClaro, 0.3);
  g.fillRoundedRect(x + 48, y - 68, 8, 54, 4);
  g.fillStyle(PALETA.panel, 1);
  g.fillRoundedRect(x + 58, y - 62, 16, 16, 3);
  g.lineStyle(2, enMarcha ? PALETA.operacion : PALETA.fallo, 0.95);
  g.strokeRoundedRect(x + 58, y - 62, 16, 16, 3);
  g.fillStyle(enMarcha ? PALETA.operacion : PALETA.fallo, 1);
  g.fillCircle(x + 66, y - 54, 5);
  // tolva
  g.fillStyle(PALETA.metalClaro, 0.9);
  g.fillTriangle(x + 38, y - 76, x + 60, y - 100, x + 86, y - 76);
  // pila de botellas a la salida
  for (let i = 0; i < 4; i++) {
    dibujarToken(g, 'botella', x + 66 + (i % 2) * 8, y - 8 - Math.floor(i / 2) * 12, 0.7);
  }
}

function dibujarCuartoFrio(g, x, y, ocupacion = 0, k = 4) {
  const lleno = ocupacion >= k;
  sombra(g, x, y, 170, 38, 0.3);
  const ancho = 144;
  const alto = 92;
  const prof = 38;
  // cara frontal izquierda
  g.fillStyle(PALETA.metalOscuro, 1);
  g.fillRect(x - ancho / 2, y - alto, ancho / 2, alto);
  // cara frontal derecha
  g.fillStyle(0x5c7280, 1);
  g.fillRect(x, y - alto, ancho / 2, alto);
  // techo
  g.fillStyle(PALETA.metalClaro, 1);
  g.fillPoints([
    { x: x - ancho / 2, y: y - alto },
    { x: x, y: y - alto - prof / 2 },
    { x: x + ancho / 2, y: y - alto },
    { x: x, y: y - alto + prof / 2 }
  ], true);
  // puerta
  g.fillStyle(PALETA.panel, 1);
  g.fillRoundedRect(x - 34, y - 78, 68, 66, 6);
  g.lineStyle(2, lleno ? PALETA.fallo : PALETA.frio, 0.95);
  g.strokeRoundedRect(x - 34, y - 78, 68, 66, 6);
  g.fillStyle(PALETA.metalClaro, 1);
  g.fillRoundedRect(x + 22, y - 48, 6, 14, 2);
  // indicador
  g.fillStyle(lleno ? PALETA.fallo : PALETA.frio, 1);
  g.fillCircle(x + 46, y - 84, 6);
  g.lineStyle(2, PALETA.texto, 0.8);
  g.strokeCircle(x + 46, y - 84, 6);
  // ranuras con lotes
  for (let i = 0; i < k; i++) {
    const sx = x - 58 + (i % 2) * 54;
    const sy = y - 84 + Math.floor(i / 2) * 30;
    g.fillStyle(PALETA.panel, 0.9);
    g.fillRoundedRect(sx, sy, 22, 22, 3);
    g.lineStyle(1, lleno ? PALETA.fallo : PALETA.textoSuave, 0.6);
    g.strokeRoundedRect(sx, sy, 22, 22, 3);
    if (i < ocupacion) dibujarToken(g, 'lote', sx + 11, sy + 14, 0.8);
  }
  // termómetro
  g.fillStyle(PALETA.texto, 0.9);
  g.fillRoundedRect(x - 62, y - 70, 4, 40, 2);
  g.fillStyle(PALETA.frio, 1);
  g.fillCircle(x - 60, y - 26, 4);
}

function dibujarToken(g, tipo, x, y, escala = 1) {
  const s = escala;
  switch (tipo) {
    case 'leche': {
      g.fillStyle(PALETA.leche, 0.95);
      g.fillCircle(x, y + 2 * s, 4.5 * s);
      g.fillTriangle(x - 4.5 * s, y + 1.5 * s, x, y - 8 * s, x + 4.5 * s, y + 1.5 * s);
      break;
    }
    case 'vapor': {
      g.fillStyle(PALETA.vapor, 0.5);
      g.fillCircle(x - 4 * s, y + 2 * s, 4 * s);
      g.fillCircle(x + 3 * s, y, 5 * s);
      g.fillCircle(x, y - 4 * s, 3.5 * s);
      break;
    }
    case 'frio': {
      g.lineStyle(1.6 * s, PALETA.frio, 0.95);
      for (let i = 0; i < 3; i++) {
        const a = (i / 3) * Math.PI;
        g.lineBetween(x - Math.cos(a) * 7 * s, y - Math.sin(a) * 7 * s, x + Math.cos(a) * 7 * s, y + Math.sin(a) * 7 * s);
      }
      g.fillStyle(PALETA.frio, 1);
      g.fillCircle(x, y, 2 * s);
      break;
    }
    case 'lote': {
      const w = 9 * s;
      const h = 5 * s;
      g.fillStyle(0xb98a4a, 1);
      g.fillRect(x - w, y - h, w * 2, h * 2);
      g.fillStyle(PALETA.lote, 1);
      g.fillPoints([
        { x: x - w, y: y - h },
        { x: x - w / 2, y: y - h - 4 * s },
        { x: x + w, y: y - h - 4 * s },
        { x: x + w / 2, y: y - h }
      ], true);
      g.lineStyle(1, 0x6d4a22, 0.8);
      g.strokeRect(x - w, y - h, w * 2, h * 2);
      break;
    }
    case 'botella': {
      g.fillStyle(PALETA.botella, 0.95);
      g.fillRoundedRect(x - 3 * s, y - 8 * s, 6 * s, 12 * s, 2 * s);
      g.fillRect(x - 1.5 * s, y - 13 * s, 3 * s, 5 * s);
      g.fillStyle(PALETA.metalClaro, 1);
      g.fillRect(x - 2 * s, y - 14 * s, 4 * s, 2 * s);
      g.fillStyle(0xffffff, 0.5);
      g.fillRect(x - 2 * s, y - 6 * s, 1.5 * s, 8 * s);
      break;
    }
    case 'cupo': {
      g.fillStyle(PALETA.operacion, 0.95);
      g.fillPoints([
        { x, y: y - 6 * s },
        { x: x + 6 * s, y },
        { x, y: y + 6 * s },
        { x: x - 6 * s, y }
      ], true);
      g.lineStyle(1, PALETA.texto, 0.5);
      g.strokePoints([
        { x, y: y - 6 * s },
        { x: x + 6 * s, y },
        { x, y: y + 6 * s },
        { x: x - 6 * s, y }
      ], true);
      break;
    }
    case 'tanque': {
      g.fillStyle(PALETA.metalClaro, 0.95);
      g.fillCircle(x, y, 5 * s);
      g.lineStyle(1.5, PALETA.metalOscuro, 1);
      g.strokeCircle(x, y, 5 * s);
      break;
    }
    case 'alerta': {
      g.fillStyle(PALETA.fallo, 1);
      g.fillTriangle(x, y - 7 * s, x + 7 * s, y + 6 * s, x - 7 * s, y + 6 * s);
      g.fillStyle(PALETA.texto, 1);
      g.fillRect(x - 1 * s, y - 2 * s, 2 * s, 5 * s);
      g.fillCircle(x, y + 4 * s, 1.2 * s);
      break;
    }
    default:
      g.fillStyle(PALETA.texto, 0.9);
      g.fillCircle(x, y, 4 * s);
  }
}

function dibujarIconoEstado(g, estado, x, y, r = 12) {
  const color = COLORES_ESTADO[estado] ?? PALETA.metal;
  g.fillStyle(0x081016, 0.8);
  g.fillCircle(x + 1, y + 2, r + 1);
  g.fillStyle(color, 1);
  g.fillCircle(x, y, r);
  g.lineStyle(1.5, 0xffffff, 0.5);
  g.strokeCircle(x, y, r);
  g.lineStyle(1.8, 0xffffff, 0.92);
  if (estado === 'Vacio') {
    g.lineBetween(x - 5, y, x - 1, y + 4);
    g.lineBetween(x - 1, y + 4, x + 5, y - 4);
  } else if (estado === 'Llenando') {
    g.fillStyle(0xffffff, 0.95);
    g.fillCircle(x, y + 3, 3);
    g.fillTriangle(x - 3, y + 2, x, y - 6, x + 3, y + 2);
  } else if (estado === 'Pasteurizando') {
    g.fillStyle(0xffffff, 0.95);
    g.fillTriangle(x - 5, y + 5, x + 1, y - 6, x + 5, y + 5);
    g.fillStyle(color, 0.9);
    g.fillCircle(x + 1, y + 4, 2.4);
  } else if (estado === 'Enfriando') {
    for (let i = 0; i < 3; i++) {
      const a = (i / 3) * Math.PI;
      g.lineBetween(x - Math.cos(a) * 6, y - Math.sin(a) * 6, x + Math.cos(a) * 6, y + Math.sin(a) * 6);
    }
    g.fillStyle(0xffffff, 1);
    g.fillCircle(x, y, 1.8);
  } else if (estado === 'Lavado_CIP') {
    g.strokeCircle(x - 3, y + 2, 2.4);
    g.strokeCircle(x + 3, y + 1, 3);
    g.strokeCircle(x, y - 4, 2);
  } else if (estado === 'Fallo') {
    g.lineBetween(x, y - 5, x, y + 2);
    g.fillStyle(0xffffff, 1);
    g.fillCircle(x, y + 5, 1.4);
  }
}

function dibujarArista(g, x1, y1, x2, y2, color = PALETA.textoSuave, curvatura = 0, grosor = 2, alpha = 0.95) {
  const mx = (x1 + x2) / 2;
  const my = (y1 + y2) / 2;
  const dx = x2 - x1;
  const dy = y2 - y1;
  const largo = Math.hypot(dx, dy) || 1;
  const px = -dy / largo;
  const py = dx / largo;
  const cx = mx + px * curvatura;
  const cy = my + py * curvatura;
  const pts = [];
  for (let i = 0; i <= 18; i++) {
    const t = i / 18;
    const it = 1 - t;
    pts.push({
      x: it * it * x1 + 2 * it * t * cx + t * t * x2,
      y: it * it * y1 + 2 * it * t * cy + t * t * y2
    });
  }
  g.lineStyle(grosor, color, alpha);
  g.beginPath();
  g.moveTo(pts[0].x, pts[0].y);
  for (const p of pts.slice(1)) g.lineTo(p.x, p.y);
  g.strokePath();
  // flecha en el extremo
  const a = pts[pts.length - 2];
  const b = pts[pts.length - 1];
  const ang = Math.atan2(b.y - a.y, b.x - a.x);
  const largoFlecha = 8;
  g.fillStyle(color, alpha);
  g.fillTriangle(
    b.x, b.y,
    b.x - Math.cos(ang - 0.45) * largoFlecha, b.y - Math.sin(ang - 0.45) * largoFlecha,
    b.x - Math.cos(ang + 0.45) * largoFlecha, b.y - Math.sin(ang + 0.45) * largoFlecha
  );
  return { x: cx, y: cy };
}

function dibujarNodo(g, x, y, { actual = false, marcado = false, color = PALETA.operacion, r = 21 } = {}) {
  if (actual) {
    g.fillStyle(color, 0.18);
    g.fillCircle(x, y, r + 9);
    g.lineStyle(2, color, 0.55);
    g.strokeCircle(x, y, r + 6);
  }
  g.fillStyle(PALETA.panel, 0.98);
  g.fillCircle(x, y, r);
  g.lineStyle(2, actual ? color : PALETA.panelBorde, 1);
  g.strokeCircle(x, y, r);
  if (marcado) {
    g.lineStyle(1.5, PALETA.textoSuave, 0.85);
    g.strokeCircle(x, y, r - 4);
  }
}

// Sonidos sintetizados con Web Audio API. No usa archivos externos.
// El AudioContext se crea o reanuda en el primer gesto del usuario.
class Sonido {
  constructor() {
    this.ctx = null;
    this.activo = true;
  }

  asegurar() {
    if (!this.activo) return;
    try {
      if (!this.ctx) {
        const Ctx = window.AudioContext || window.webkitAudioContext;
        if (!Ctx) {
          this.activo = false;
          return;
        }
        this.ctx = new Ctx();
      }
      if (this.ctx.state === 'suspended') this.ctx.resume();
    } catch {
      this.activo = false;
    }
  }

  _tono(frecuencia, duracion = 0.08, tipo = 'sine', volumen = 0.04, retardo = 0) {
    if (!this.activo) return;
    this.asegurar();
    if (!this.ctx) return;
    try {
      const t0 = this.ctx.currentTime + retardo;
      const osc = this.ctx.createOscillator();
      const gan = this.ctx.createGain();
      osc.type = tipo;
      osc.frequency.setValueAtTime(frecuencia, t0);
      gan.gain.setValueAtTime(Math.max(0.0001, volumen), t0);
      gan.gain.exponentialRampToValueAtTime(0.0001, t0 + duracion);
      osc.connect(gan);
      gan.connect(this.ctx.destination);
      osc.start(t0);
      osc.stop(t0 + duracion + 0.02);
    } catch {
      // Si el navegador bloquea el audio, el juego sigue sin sonido.
    }
  }

  clic() {
    this._tono(520, 0.05, 'square', 0.025);
  }

  transicion() {
    this._tono(440, 0.07, 'triangle', 0.03);
  }

  botella() {
    this._tono(660, 0.08, 'sine', 0.04);
    this._tono(880, 0.1, 'sine', 0.03, 0.06);
  }

  fallo() {
    this._tono(180, 0.22, 'sawtooth', 0.035);
    this._tono(120, 0.3, 'sawtooth', 0.03, 0.08);
  }

  bloqueado() {
    this._tono(110, 0.12, 'square', 0.035);
  }

  logro() {
    [523, 659, 784].forEach((f, i) => this._tono(f, 0.18, 'sine', 0.035, i * 0.09));
  }

  deadlock() {
    [220, 180, 140, 100].forEach((f, i) => this._tono(f, 0.3, 'sawtooth', 0.035, i * 0.12));
  }

  victoria() {
    [523, 659, 784, 1046].forEach((f, i) => this._tono(f, 0.24, 'sine', 0.04, i * 0.11));
  }
}

const sonido = new Sonido();

const FUENTE = '"Trebuchet MS", "Segoe UI", sans-serif';
const MONO = 'Consolas, "Courier New", monospace';

function texto(escena, x, y, contenido, opciones = {}) {
  const {
    fontSize = '12px',
    color = hex(PALETA.texto),
    fontFamily = FUENTE,
    align = 'left',
    ...resto
  } = opciones;
  return escena.add.text(x, y, contenido, { fontFamily, fontSize, color, align, ...resto });
}

function boton(escena, x, y, ancho, alto, etiqueta, onClick, opciones = {}) {
  const {
    color = PALETA.panelBorde,
    hover = PALETA.metalOscuro,
    textoColor = PALETA.texto,
    fontSize = '12px',
    borde = PALETA.metal
  } = opciones;
  const fondo = escena.add.rectangle(x, y, ancho, alto, color, 1).setOrigin(0.5);
  fondo.setStrokeStyle(1.5, borde, 0.85);
  fondo.setInteractive({ useHandCursor: true });
  const label = escena.add.text(x, y, etiqueta, {
    fontFamily: FUENTE,
    fontSize,
    color: hex(textoColor),
    align: 'center'
  }).setOrigin(0.5);

  fondo.on('pointerover', () => fondo.setFillStyle(hover, 1));
  fondo.on('pointerout', () => fondo.setFillStyle(color, 1));
  fondo.on('pointerdown', (pointer) => {
    pointer?.event?.stopPropagation?.();
    sonido.asegurar();
    sonido.clic();
    onClick?.(pointer);
  });

  return {
    fondo,
    label,
    setColor: (c) => fondo.setFillStyle(c, 1),
    setLabel: (t) => label.setText(t),
    setEnabled: (v) => {
      if (v) {
        fondo.setInteractive({ useHandCursor: true });
        label.setAlpha(1);
      } else {
        fondo.disableInteractive();
        label.setAlpha(0.45);
      }
    },
    destruir: () => {
      fondo.destroy();
      label.destroy();
    }
  };
}

function panel(escena, x, y, ancho, alto, alpha = 0.95, borde = PALETA.panelBorde) {
  const g = escena.add.graphics();
  g.fillStyle(PALETA.panel, alpha);
  g.fillRoundedRect(x, y, ancho, alto, 10);
  g.lineStyle(1.5, borde, 0.9);
  g.strokeRoundedRect(x, y, ancho, alto, 10);
  g.fillStyle(PALETA.acento, 0.8);
  g.fillRect(x + 12, y + 1, ancho - 24, 2);
  return g;
}

function formatoTiempo(segundos) {
  const s = Math.max(0, Math.floor(segundos));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}`;
}

function separar(numero) {
  return String(Math.round(numero)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

class Arranque extends Phaser.Scene {
  constructor() {
    super('Arranque');
  }

  create() {
    this.cameras.main.setBackgroundColor(hex(PALETA.fondo));
    const g = this.add.graphics();
    dibujarSuelo(g, 18, 480, 120);
    g.fillStyle(PALETA.fondo, 0.72);
    g.fillRect(0, 0, 960, 540);

    this.add.text(480, 190, 'DairyCraft 2.5D', {
      fontFamily: FUENTE,
      fontSize: '42px',
      color: hex(PALETA.leche),
      fontStyle: 'bold'
    }).setOrigin(0.5).setShadow(0, 4, '#000000', 8);

    this.add.text(480, 238, 'Planta pasteurizadora y láctea · AEF + Redes de Petri', {
      fontFamily: FUENTE,
      fontSize: '15px',
      color: hex(PALETA.textoSuave)
    }).setOrigin(0.5);

    const progreso = { valor: 0 };
    const barra = this.add.graphics();
    const dibujar = () => {
      barra.clear();
      barra.fillStyle(PALETA.muro, 1);
      barra.fillRoundedRect(280, 300, 400, 14, 7);
      barra.fillStyle(PALETA.operacion, 1);
      barra.fillRoundedRect(280, 300, Math.max(14, 400 * progreso.valor), 14, 7);
      barra.lineStyle(1.5, PALETA.panelBorde, 1);
      barra.strokeRoundedRect(280, 300, 400, 14, 7);
    };
    dibujar();

    texto(this, 480, 336, 'Cargando Phaser 4.2.1 por CDN…', {
      fontSize: '12px',
      color: hex(PALETA.textoSuave)
    }).setOrigin(0.5);

    this.tweens.add({
      targets: progreso,
      valor: 1,
      duration: 1200,
      ease: 'Sine.easeInOut',
      onUpdate: dibujar,
      onComplete: () => this.scene.start('Titulo')
    });
  }
}

class Titulo extends Phaser.Scene {
  constructor() {
    super('Titulo');
  }

  create() {
    this.cameras.main.setBackgroundColor(hex(PALETA.fondo));
    const g = this.add.graphics();
    dibujarSuelo(g, 16, 480, 60);

    // Planta de fondo, dibujada en código
    const fondo = this.add.graphics();
    dibujarSilo(fondo, 700, 330, 6, 10);
    dibujarTanque(fondo, 790, 380, 'Pasteurizando', 0.9);
    dibujarTanque(fondo, 690, 440, 'Enfriando', 0.8);
    dibujarCaldera(fondo, 870, 300, true);
    dibujarChiller(fondo, 850, 440, true);
    dibujarEmbotelladora(fondo, 760, 500, 'Emb_lista');
    dibujarCuartoFrio(fondo, 880, 510, 2, 4);
    for (let i = 0; i < 5; i++) dibujarToken(fondo, 'leche', 656 + i * 14, 250, 0.8);

    const velo = this.add.graphics();
    velo.fillStyle(PALETA.fondo, 0.66);
    velo.fillRect(0, 0, 960, 540);

    // Título
    texto(this, 64, 74, 'DairyCraft 2.5D', {
      fontSize: '44px',
      color: hex(PALETA.leche),
      fontStyle: 'bold'
    }).setShadow(0, 4, '#000000', 10);
    texto(this, 66, 126, 'Planta pasteurizadora y láctea · simulador isométrico 2.5D', {
      fontSize: '15px',
      color: hex(PALETA.textoSuave)
    });
    texto(this, 66, 150, 'Modelado y Simulación de Sistemas de Eventos Discretos · Fase 1', {
      fontSize: '11px',
      color: hex(PALETA.acento)
    });

    panel(this, 54, 186, 540, 254, 0.9);
    texto(this, 76, 202, 'Cómo jugar', {
      fontSize: '17px',
      color: hex(PALETA.acento),
      fontStyle: 'bold'
    });

    const lineas = [
      '1. Haz clic en un tanque para abrir el HUD de su autómata.',
      '2. Abre la válvula, pasteuriza y descarga cuando el frío esté listo.',
      '3. La red mueve leche, vapor, frío, lotes y cupo: nada es gratis.',
      '4. Si un tanque falla, escribe la receta CIP con P, S, E, A, Z.',
      '5. Mira el radar: verde, amarillo o rojo. Activa Cupo_frio a tiempo.',
      '6. Objetivo: 6 lotes embotellados en 3 minutos de simulación.'
    ];
    lineas.forEach((linea, i) => {
      texto(this, 78, 238 + i * 27, linea, {
        fontSize: '12px',
        color: hex(PALETA.texto)
      });
    });

    panel(this, 618, 186, 292, 254, 0.9);
    texto(this, 638, 202, 'Controles', {
      fontSize: '17px',
      color: hex(PALETA.acento),
      fontStyle: 'bold'
    });
    const controles = [
      ['Clic / toque', 'abrir el HUD del tanque'],
      ['P', 'pausa / reanudar'],
      ['I', 'inspector de la red'],
      ['1 · 2 · 4', 'velocidad de simulación'],
      ['Esc', 'cerrar panel'],
      ['F1', 'fps y tiempo'],
      ['Arrastre + rueda', 'mover y acercar la cámara']
    ];
    controles.forEach(([tecla, accion], i) => {
      texto(this, 638, 238 + i * 24, tecla, {
        fontSize: '11px',
        color: hex(PALETA.acento),
        fontFamily: 'Consolas, monospace'
      });
      texto(this, 732, 238 + i * 24, accion, {
        fontSize: '11px',
        color: hex(PALETA.textoSuave)
      });
    });

    boton(this, 168, 478, 228, 48, '▶  Iniciar turno', () => { sonido.asegurar(); this.scene.start('Planta'); }, {
      color: PALETA.operacion,
      hover: 0x38b86c,
      borde: 0x9be3c0,
      fontSize: '17px',
      textoColor: PALETA.leche
    });

    texto(this, 64, 474, 'Equipo', {
      fontSize: '10px',
      color: hex(PALETA.textoSuave)
    });
    texto(this, 64, 490, 'Deivid Peñaloza · Paula Mendoza', {
      fontSize: '11px',
      color: hex(PALETA.texto)
    });
    texto(this, 64, 505, 'Fabian Garcia · Daniel Castellanos', {
      fontSize: '11px',
      color: hex(PALETA.texto)
    });

    texto(this, 930, 520, 'Phaser 4.2.1 · Vite', {
      fontSize: '10px',
      color: hex(PALETA.textoSuave)
    }).setOrigin(1, 0.5);

    // Pequeño destello decorativo
    const brillo = this.add.circle(700, 330, 80, PALETA.acento, 0.05);
    this.tweens.add({
      targets: brillo,
      alpha: 0.12,
      scale: 1.2,
      duration: 2200,
      yoyo: true,
      repeat: -1
    });
  }
}

// Autómata de estado finito determinista G = (Q, Sigma, delta, q0, Qm).
// Toda transición del juego pasa por este ejecutar(); no hay cambios de estado sueltos.
class Automata {
  constructor(json) {
    this.json = json;
    this.estado = json.inicial;
    this.historial = [];
    this.eventosPorId = new Map(json.eventos.map((e) => [e.id, e]));
    this.delta = new Map();

    for (const [origen, evento, destino] of json.transiciones) {
      if (!json.estados.includes(origen) || !json.estados.includes(destino)) {
        throw new Error(`Estado desconocido en la transición ${origen} -${evento}-> ${destino}`);
      }
      if (!this.eventosPorId.has(evento)) {
        throw new Error(`Evento desconocido en la transición: ${evento}`);
      }
      if (!this.delta.has(origen)) this.delta.set(origen, new Map());
      if (this.delta.get(origen).has(evento)) {
        throw new Error(`El autómata ${json.nombre} no es determinista en (${origen}, ${evento})`);
      }
      this.delta.get(origen).set(evento, destino);
    }
  }

  eventosActivos() {
    const salidas = this.delta.get(this.estado) ?? new Map();
    return [...salidas.keys()].map((id) => this.eventosPorId.get(id));
  }

  transicionesActivas() {
    const salidas = this.delta.get(this.estado) ?? new Map();
    return [...salidas.entries()].map(([id, destino]) => ({
      evento: this.eventosPorId.get(id),
      destino
    }));
  }

  puede(eventoId) {
    return (this.delta.get(this.estado) ?? new Map()).has(eventoId);
  }

  ejecutar(eventoId) {
    const salida = this.delta.get(this.estado) ?? new Map();
    if (!salida.has(eventoId)) {
      throw new Error(
        `delta(${this.estado}, ${eventoId}) no está definida en el autómata ${this.json.nombre}`
      );
    }
    const destino = salida.get(eventoId);
    this.estado = destino;
    this.historial.push(eventoId);
    return destino;
  }

  esMarcado() {
    return this.json.marcados.includes(this.estado);
  }

  reiniciar() {
    this.estado = this.json.inicial;
    this.historial = [];
  }

  codigoDe(eventoId) {
    return this.eventosPorId.get(eventoId)?.codigo ?? '?';
  }

  historialCodigos(n = 10) {
    return this.historial.slice(-n).map((id) => this.codigoDe(id));
  }

  clonar() {
    const copia = new Automata(this.json);
    copia.estado = this.estado;
    copia.historial = [...this.historial];
    return copia;
  }
}

// Red de Petri N = (P, T, Pre, Post, M0) con capacidad por lugar.
// Pre y Post son |T| x |P| (fila por transición); A = Post - Pre.
// M_k = M_{k-1} + A^T * u_k, con u_k el vector de disparo one-hot.
class RedPetri {
  constructor(json, { monitorActivo = true } = {}) {
    this.json = json;
    this.lugares = json.lugares.map((p) => ({ ...p }));
    this.transiciones = json.transiciones.map((t) => ({ ...t }));
    this.nP = this.lugares.length;
    this.nT = this.transiciones.length;
    this.idxLugar = new Map(this.lugares.map((p, i) => [p.id, i]));
    this.idxTransicion = new Map(this.transiciones.map((t, i) => [t.id, i]));
    this.preBase = json.pre.map((fila) => [...fila]);
    this.postBase = json.post.map((fila) => [...fila]);
    this.M0Base = this.lugares.map((p) => p.m0);
    this.monitor = json.monitor ?? null;
    this.monitorActivo = monitorActivo;
    this.pre = [];
    this.post = [];
    this.A = [];
    this.M = [...this.M0Base];
    this.disparos = [];
    this.reconstruirMatrices();
    this.reiniciar();
  }

  _ti(transicion) {
    if (typeof transicion === 'number') return transicion;
    if (typeof transicion === 'string') return this.idxTransicion.get(transicion) ?? -1;
    return this.idxTransicion.get(transicion?.id) ?? -1;
  }

  _pi(lugar) {
    if (typeof lugar === 'number') return lugar;
    if (typeof lugar === 'string') return this.idxLugar.get(lugar) ?? -1;
    return this.idxLugar.get(lugar?.id) ?? -1;
  }

  reconstruirMatrices() {
    this.pre = this.preBase.map((fila) => [...fila]);
    this.post = this.postBase.map((fila) => [...fila]);
    if (this.monitor && !this.monitorActivo) {
      const idx = this.idxLugar.get(this.monitor.lugar);
      for (const id of this.monitor.transiciones) {
        const ti = this.idxTransicion.get(id);
        if (ti !== undefined && idx !== undefined) {
          this.pre[ti][idx] = 0;
          this.post[ti][idx] = 0;
        }
      }
    }
    this.A = this.post.map((fila, t) => fila.map((v, p) => v - this.pre[t][p]));
  }

  marcadoInicial() {
    const M = [...this.M0Base];
    if (this.monitor) {
      const idx = this.idxLugar.get(this.monitor.lugar);
      M[idx] = this.monitorActivo ? this.monitor.m0 : 0;
    }
    return M;
  }

  reiniciar() {
    this.M = this.marcadoInicial();
    this.disparos = [];
    return this;
  }

  setMonitor(activo) {
    this.monitorActivo = Boolean(activo);
    this.reconstruirMatrices();
    if (this.monitor) {
      const idx = this.idxLugar.get(this.monitor.lugar);
      if (this.monitorActivo) {
        const comprometidos =
          this.M[this.idxLugar.get('lote_past')] +
          this.M[this.idxLugar.get('lote_enfr')] +
          this.M[this.idxLugar.get('cuarto')];
        this.M[idx] = Math.max(0, this.monitor.m0 - comprometidos);
      } else {
        this.M[idx] = 0;
      }
    }
    return this;
  }

  habilitada(transicion, M = this.M) {
    const ti = this._ti(transicion);
    if (ti < 0) return false;
    const pre = this.pre[ti];
    const post = this.post[ti];
    for (let p = 0; p < this.nP; p++) {
      if (M[p] < pre[p]) return false;
    }
    for (let p = 0; p < this.nP; p++) {
      const m2 = M[p] - pre[p] + post[p];
      if (m2 < 0) return false;
      if (this.lugares[p].capacidad === 'estricta' && m2 > this.lugares[p].k) return false;
    }
    return true;
  }

  razonNoHabilitada(transicion, M = this.M) {
    const ti = this._ti(transicion);
    if (ti < 0) return { habilitada: false, faltan: [], excede: [], texto: 'Transición desconocida' };
    const faltan = [];
    const excede = [];
    for (let p = 0; p < this.nP; p++) {
      const pre = this.pre[ti][p];
      if (M[p] < pre) {
        faltan.push({ lugar: this.lugares[p].nombre, tiene: M[p], necesita: pre });
      }
      const m2 = M[p] - pre + this.post[ti][p];
      if (this.lugares[p].capacidad === 'estricta' && m2 > this.lugares[p].k) {
        excede.push({ lugar: this.lugares[p].nombre, resultante: m2, k: this.lugares[p].k });
      }
    }
    const partes = [];
    if (faltan.length) partes.push('faltan tokens: ' + faltan.map((f) => `${f.lugar} ${f.tiene}/${f.necesita}`).join(', '));
    if (excede.length) partes.push('capacidad estricta: ' + excede.map((e) => `${e.lugar} ${e.resultante}/${e.k}`).join(', '));
    return {
      habilitada: faltan.length === 0 && excede.length === 0,
      faltan,
      excede,
      texto: partes.length ? partes.join(' · ') : 'habilitada'
    };
  }

  resultado(transicion, M = this.M) {
    const ti = this._ti(transicion);
    if (ti < 0 || !this.habilitada(ti, M)) return null;
    const salida = M.map((v, p) => v - this.pre[ti][p] + this.post[ti][p]);
    return salida;
  }

  disparar(transicion) {
    const ti = this._ti(transicion);
    const antes = [...this.M];
    const despues = this.resultado(ti, this.M);
    if (!despues) {
      throw new Error(`La transición ${this.transiciones[ti]?.id ?? transicion} no está habilitada`);
    }
    const u = this.transiciones.map((_, i) => (i === ti ? 1 : 0));
    const desborde = [];
    for (let p = 0; p < this.nP; p++) {
      if (despues[p] > this.lugares[p].k) {
        desborde.push({ lugar: this.lugares[p].nombre, valor: despues[p], k: this.lugares[p].k });
      }
    }
    this.M = despues;
    this.disparos.push({ transicion: this.transiciones[ti].id, antes, despues: [...despues], u });
    return {
      id: this.transiciones[ti].id,
      antes,
      despues: [...despues],
      u,
      desborde
    };
  }

  habilitadas(M = this.M) {
    const salida = [];
    for (let t = 0; t < this.nT; t++) {
      if (this.habilitada(t, M)) salida.push(this.transiciones[t].id);
    }
    return salida;
  }

  conflictos(M = this.M) {
    const activas = this.habilitadas(M);
    const pares = [];
    for (let a = 0; a < activas.length; a++) {
      for (let b = a + 1; b < activas.length; b++) {
        const ta = this._ti(activas[a]);
        const tb = this._ti(activas[b]);
        for (let p = 0; p < this.nP; p++) {
          if (this.pre[ta][p] > 0 && this.pre[tb][p] > 0) {
            pares.push({ a: activas[a], b: activas[b], lugar: this.lugares[p].nombre });
            break;
          }
        }
      }
    }
    return pares;
  }

  esMuerto(M = this.M) {
    return this.habilitadas(M).length === 0;
  }

  marcado() {
    return [...this.M];
  }

  marcadoObj(M = this.M) {
    const obj = {};
    this.lugares.forEach((p, i) => {
      obj[p.id] = M[i];
    });
    return obj;
  }

  agregarToken(lugar, cantidad = 1) {
    const pi = this._pi(lugar);
    if (pi < 0) throw new Error(`Lugar desconocido: ${lugar}`);
    const p = this.lugares[pi];
    const limite = p.capacidad === 'estricta' ? p.k : p.k + 3;
    const antes = this.M[pi];
    const nuevo = Math.min(limite, antes + cantidad);
    this.M[pi] = nuevo;
    return {
      lugar: p.nombre,
      antes,
      despues: nuevo,
      desborde: nuevo > p.k,
      excedido: antes + cantidad > limite
    };
  }

  verificarInvariantes(M = this.M, { omitirCupo = !this.monitorActivo } = {}) {
    const resultados = [];
    for (const inv of this.json.invariantes ?? []) {
      if (omitirCupo && inv.nombre.toLowerCase().includes('cupo')) continue;
      let suma = 0;
      for (const [id, peso] of Object.entries(inv.pesos)) {
        const pi = this.idxLugar.get(id);
        if (pi === undefined) throw new Error(`Invariante con lugar desconocido: ${id}`);
        suma += M[pi] * peso;
      }
      resultados.push({ nombre: inv.nombre, esperado: inv.valor, obtenido: suma, ok: suma === inv.valor });
    }
    return { ok: resultados.every((r) => r.ok), resultados };
  }

  matrices() {
    return {
      pre: this.pre.map((f) => [...f]),
      post: this.post.map((f) => [...f]),
      A: this.A.map((f) => [...f])
    };
  }

  ultimoDisparo() {
    return this.disparos[this.disparos.length - 1] ?? null;
  }

  clonar() {
    const copia = new RedPetri(this.json, { monitorActivo: this.monitorActivo });
    copia.M = [...this.M];
    copia.disparos = this.disparos.map((d) => ({ ...d, antes: [...d.antes], despues: [...d.despues], u: [...d.u] }));
    return copia;
  }

  nombresLugares() {
    return this.lugares.map((p) => p.nombre);
  }

  idsLugares() {
    return this.lugares.map((p) => p.id);
  }

  nombresTransiciones() {
    return this.transiciones.map((t) => t.id);
  }
}

// Reloj de simulación por eventos discretos: calendario de eventos futuros
// implementado con una cola de prioridad (arreglo ordenado por tiempo y secuencia).
class Reloj {
  constructor(tiempo = 0) {
    this.tiempo = tiempo;
    this.eventos = [];
    this.secuencia = 0;
    this.pausado = false;
    this.disparados = 0;
  }

  programar(dt, callback, etiqueta = null) {
    const t = this.tiempo + Math.max(0, Number(dt) || 0);
    const evento = { t, callback, etiqueta, seq: this.secuencia++ };
    let i = this.eventos.length;
    while (i > 0 && (this.eventos[i - 1].t > t || (this.eventos[i - 1].t === t && this.eventos[i - 1].seq > evento.seq))) i--;
    this.eventos.splice(i, 0, evento);
    return evento;
  }

  avanzar(dt) {
    if (this.pausado) return this.tiempo;
    const objetivo = this.tiempo + Math.max(0, Number(dt) || 0);
    while (this.eventos.length && this.eventos[0].t <= objetivo) {
      const evento = this.eventos.shift();
      this.tiempo = evento.t;
      this.disparados++;
      evento.callback?.(evento);
      // Si un callback limpió el reloj, el while se detiene solo.
    }
    this.tiempo = objetivo;
    return this.tiempo;
  }

  cancelar(etiqueta) {
    this.eventos = this.eventos.filter((e) => e.etiqueta !== etiqueta);
  }

  limpiar() {
    this.eventos = [];
  }

  pausar() {
    this.pausado = true;
  }

  reanudar() {
    this.pausado = false;
  }

  pendientes() {
    return this.eventos.length;
  }
}

// Generador pseudoaleatorio con semilla (mulberry32) para partidas reproducibles.
class Aleatorio {
  constructor(semilla = 1) {
    this.semilla = semilla >>> 0;
    this.estado = this.semilla;
  }

  reiniciar() {
    this.estado = this.semilla;
  }

  siguiente() {
    let a = (this.estado = (this.estado + 0x6d2b79f5) >>> 0);
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  entero(min, max) {
    return Math.floor(this.siguiente() * (max - min + 1)) + min;
  }

  probabilidad(p) {
    return this.siguiente() < p;
  }

  elegir(lista) {
    if (!lista.length) return undefined;
    return lista[this.entero(0, lista.length - 1)];
  }
}

// Validador del lenguaje de reparación: RegExp anclada + DFA exportado de JFLAP.
// El alfabeto del CIP es {P, S, E, A, Z}. La palabra válida de la ficha es PSESEAEZ.
class Lenguaje {
  constructor(json) {
    this.json = json;
    this.regex = new RegExp(json.regex);
    this.simbolos = [...json.simbolos];
    this.inicial = json.inicial;
    this.finales = new Set(json.finales);
    this.delta = new Map();
    for (const [origen, simbolo, destino] of json.transiciones) {
      if (!this.delta.has(origen)) this.delta.set(origen, new Map());
      this.delta.get(origen).set(simbolo, destino);
    }
    this.reiniciar();
  }

  reiniciar() {
    this.estado = this.inicial;
    this.palabra = '';
    this.ultimo = null;
    return this;
  }

  siguientes() {
    return [...(this.delta.get(this.estado)?.keys() ?? [])];
  }

  avanzar(simbolo) {
    const s = String(simbolo).toUpperCase();
    if (!this.simbolos.includes(s)) {
      this.ultimo = {
        ok: false,
        motivo: `El símbolo "${s}" no pertenece al alfabeto de reparación {${this.simbolos.join(', ')}}.`,
        esperado: this.siguientes()
      };
      return this.ultimo;
    }
    const destino = this.delta.get(this.estado)?.get(s);
    if (!destino) {
      this.ultimo = {
        ok: false,
        motivo: `Desde ${this.estado} no hay transición con ${s}.`,
        esperado: this.siguientes()
      };
      return this.ultimo;
    }
    this.estado = destino;
    this.palabra += s;
    this.ultimo = {
      ok: true,
      estado: this.estado,
      palabra: this.palabra,
      acepta: this.esValida(),
      esperado: this.siguientes()
    };
    return this.ultimo;
  }

  esValida() {
    return this.finales.has(this.estado);
  }

  perteneceDFA(palabra) {
    let q = this.inicial;
    for (const ch of String(palabra).toUpperCase()) {
      const siguiente = this.delta.get(q)?.get(ch);
      if (!siguiente) return false;
      q = siguiente;
    }
    return this.finales.has(q);
  }

  perteneceRegex(palabra) {
    return this.regex.test(String(palabra).toUpperCase());
  }

  pertenece(palabra) {
    return this.perteneceRegex(palabra) && this.perteneceDFA(palabra);
  }

  validar(palabra) {
    return {
      palabra: String(palabra).toUpperCase(),
      regex: this.perteneceRegex(palabra),
      dfa: this.perteneceDFA(palabra),
      coincide: this.pertenece(palabra)
    };
  }

  progreso() {
    return { estado: this.estado, palabra: this.palabra, acepta: this.esValida(), siguientes: this.siguientes() };
  }
}

// Emisor de eventos mínimo para que el núcleo SED no dependa de Phaser.
class Emisor {
  constructor() {
    this.oyentes = new Map();
  }

  on(evento, fn) {
    if (!this.oyentes.has(evento)) this.oyentes.set(evento, new Set());
    this.oyentes.get(evento).add(fn);
    return () => this.off(evento, fn);
  }

  off(evento, fn) {
    this.oyentes.get(evento)?.delete(fn);
  }

  emitir(evento, datos) {
    const lista = this.oyentes.get(evento);
    if (!lista) return;
    for (const fn of [...lista]) fn(datos);
  }

  limpiar() {
    this.oyentes.clear();
  }
}

// Composición síncrona, supervisor y el supervisor concreto del circuito CIP.
// El supervisor de la ficha: hay un solo circuito CIP, así que dos tanques no
// pueden estar en Lavado_CIP al mismo tiempo.

// Supervisor concreto del proyecto 1: un solo circuito CIP para 3 tanques.
class SupervisorCIP {
  constructor(automatas) {
    this.automatas = automatas;
  }

  ocupadoPor() {
    const i = this.automatas.findIndex((a) => a.estado === 'Lavado_CIP');
    return i >= 0 ? i : null;
  }

  eventosDeshabilitados(indice) {
    const ocupado = this.ocupadoPor();
    if (ocupado !== null && ocupado !== indice) {
      return [
        {
          evento: 'iniciar_CIP',
          razon: `Circuito CIP ocupado por Tanque ${ocupado + 1} (un solo circuito en la planta)`
        }
      ];
    }
    return [];
  }

  puede(indice, evento) {
    return !this.eventosDeshabilitados(indice).some((d) => d.evento === evento);
  }

  estado() {
    return {
      ocupadoPor: this.ocupadoPor(),
      tanquesEnCIP: this.automatas.map((a, i) => (a.estado === 'Lavado_CIP' ? i + 1 : null)).filter(Boolean)
    };
  }
}

// Árbol de cobertura de Karp y Miller y exploración limitada para el radar.
// En una red acotada, el árbol coincide con el grafo de alcanzabilidad salvo
// que el árbol no fusiona caminos; por eso también se ofrece grafoAlcanzabilidad
// (marcados distintos), que es el número que se compara con PIPE2.

const clave = (M) => M.join(',');

function explorar(red, M, profundidad = 3, maxNodos = 800) {
  const raiz = { id: 'M0', marcado: [...M], nivel: 0, muerto: red.esMuerto(M) };
  const nodos = [raiz];
  const aristas = [];
  const mapa = new Map([[clave(M), raiz]]);
  const cola = [{ nodo: raiz, M: [...M] }];

  while (cola.length && nodos.length < maxNodos) {
    const { nodo, M: actual } = cola.shift();
    if (nodo.nivel >= profundidad) continue;
    for (const t of red.habilitadas(actual)) {
      const siguiente = red.resultado(t, actual);
      if (!siguiente) continue;
      const k = clave(siguiente);
      let destino = mapa.get(k);
      if (!destino) {
        destino = {
          id: `M${nodos.length}`,
          marcado: siguiente,
          nivel: nodo.nivel + 1,
          muerto: red.esMuerto(siguiente)
        };
        nodos.push(destino);
        mapa.set(k, destino);
        cola.push({ nodo: destino, M: siguiente });
      }
      aristas.push({ de: nodo.id, a: destino.id, transicion: t });
      if (nodos.length >= maxNodos) break;
    }
  }

  return {
    nodos,
    aristas,
    muertos: nodos.filter((n) => n.muerto),
    profundidad,
    truncado: nodos.length >= maxNodos
  };
}

function grafoAlcanzabilidad(red, M0, maxNodos = 10000) {
  const raiz = { id: 'M0', marcado: [...M0], muerto: red.esMuerto(M0) };
  const nodos = [raiz];
  const aristas = [];
  const mapa = new Map([[clave(M0), raiz]]);
  const cola = [raiz];
  let completo = true;

  while (cola.length) {
    const nodo = cola.shift();
    for (const t of red.habilitadas(nodo.marcado)) {
      const siguiente = red.resultado(t, nodo.marcado);
      if (!siguiente) continue;
      const k = clave(siguiente);
      let destino = mapa.get(k);
      if (!destino) {
        if (nodos.length >= maxNodos) {
          completo = false;
          break;
        }
        destino = {
          id: `M${nodos.length}`,
          marcado: siguiente,
          muerto: red.esMuerto(siguiente)
        };
        nodos.push(destino);
        mapa.set(k, destino);
        cola.push(destino);
      }
      aristas.push({ de: nodo.id, a: destino.id, transicion: t });
    }
    if (!completo) break;
  }

  return {
    nodos,
    aristas,
    muertos: nodos.filter((n) => n.muerto),
    completo,
    total: nodos.length
  };
}

const nombre$2 = "Tanque";
const descripcion$2 = "Autómata de un tanque pasteurizador. q0 = Vacio; Qm = {Vacio}. Los fallos se detectan durante el llenado (recepción), de modo que el CIP no retiene tokens de la red.";
const estados$1 = ["Vacio","Llenando","Pasteurizando","Enfriando","Lavado_CIP","Fallo"];
const inicial$1 = "Vacio";
const marcados = ["Vacio"];
const eventos = [{"id":"abrir_valvula","codigo":"a","nombre":"Abrir válvula","controlable":true,"observable":true},{"id":"iniciar_past","codigo":"p","nombre":"Iniciar pasteurización","controlable":true,"observable":true},{"id":"fin_past","codigo":"f","nombre":"Fin de pasteurización","controlable":false,"observable":true},{"id":"descargar","codigo":"d","nombre":"Descargar al cuarto frío","controlable":true,"observable":true},{"id":"contaminacion","codigo":"x","nombre":"Contaminación","controlable":false,"observable":true},{"id":"perdida_temp","codigo":"t","nombre":"Pérdida de temperatura","controlable":false,"observable":true},{"id":"iniciar_CIP","codigo":"i","nombre":"Iniciar lavado CIP","controlable":true,"observable":true},{"id":"CIP_ok","codigo":"c","nombre":"CIP validado","controlable":false,"observable":true}];
const transiciones$2 = [["Vacio","abrir_valvula","Llenando"],["Llenando","iniciar_past","Pasteurizando"],["Llenando","contaminacion","Fallo"],["Llenando","perdida_temp","Fallo"],["Pasteurizando","fin_past","Enfriando"],["Enfriando","descargar","Vacio"],["Fallo","iniciar_CIP","Lavado_CIP"],["Lavado_CIP","CIP_ok","Vacio"]];
const posiciones$1 = {"Vacio":[190,48],"Llenando":[62,155],"Pasteurizando":[190,155],"Enfriando":[318,155],"Fallo":[88,300],"Lavado_CIP":[240,280]};
const tanqueJson = {
  nombre: nombre$2,
  descripcion: descripcion$2,
  estados: estados$1,
  inicial: inicial$1,
  marcados,
  eventos,
  transiciones: transiciones$2,
  posiciones: posiciones$1,
};

const nombre$1 = "DairyCraft";
const descripcion$1 = "Red de Petri de la planta láctea: 3 tanques, caldera (vapor), bomba de frío, embotelladora y cuarto frío. Pre/Post son |T| x |P|; A = Post - Pre.";
const lugares = [{"id":"leche","nombre":"Leche_cruda","m0":6,"k":10,"capacidad":"desborde","descripcion":"Silo de leche cruda; las llegadas externas agregan tokens."},{"id":"tanque","nombre":"Tanque_libre","m0":3,"k":3,"capacidad":"estricta","descripcion":"Tanques disponibles para pasteurizar."},{"id":"vapor","nombre":"Vapor_disp","m0":1,"k":1,"capacidad":"estricta","descripcion":"Caldera de vapor; recurso compartido entre pasteurizar y arrancar la embotelladora."},{"id":"frio","nombre":"Frio_disp","m0":1,"k":1,"capacidad":"estricta","descripcion":"Bomba de frío; se retiene durante el enfriamiento."},{"id":"lote_past","nombre":"Lote_past","m0":0,"k":3,"capacidad":"estricta","descripcion":"Lote en pasteurización."},{"id":"lote_enfr","nombre":"Lote_enfr","m0":0,"k":3,"capacidad":"estricta","descripcion":"Lote en enfriamiento."},{"id":"cuarto","nombre":"Cuarto_frio","m0":0,"k":4,"capacidad":"estricta","descripcion":"Cuarto frío; capacidad estricta de 4 lotes."},{"id":"emb_lista","nombre":"Emb_lista","m0":1,"k":1,"capacidad":"estricta","descripcion":"Embotelladora en marcha."},{"id":"emb_parada","nombre":"Emb_parada","m0":0,"k":1,"capacidad":"estricta","descripcion":"Embotelladora detenida; para arrancar necesita vapor."},{"id":"botellas","nombre":"Botellas","m0":0,"k":999,"capacidad":"desborde","descripcion":"Lotes embotellados (salida del sistema)."},{"id":"cupo","nombre":"Cupo_frio","m0":4,"k":4,"capacidad":"estricta","descripcion":"Lugar monitor de prevención del deadlock: limita a 4 los lotes en el circuito."}];
const transiciones$1 = [{"id":"t_iniciar_past","nombre":"Iniciar pasteurización","disparo":"jugador"},{"id":"t_fin_past","nombre":"Fin de pasteurización","disparo":"automatica"},{"id":"t_fin_enfr","nombre":"Descargar al cuarto frío","disparo":"jugador"},{"id":"t_embotellar","nombre":"Embotellar un lote","disparo":"automatica"},{"id":"t_parar_emb","nombre":"Parar embotelladora","disparo":"jugador"},{"id":"t_arrancar_emb","nombre":"Arrancar embotelladora","disparo":"jugador"}];
const pre = [[1,1,1,0,0,0,0,0,0,0,1],[0,0,0,1,1,0,0,0,0,0,0],[0,0,0,0,0,1,0,0,0,0,0],[0,0,0,0,0,0,1,1,0,0,0],[0,0,0,0,0,0,0,1,0,0,0],[0,0,1,0,0,0,0,0,1,0,0]];
const post = [[0,0,0,0,1,0,0,0,0,0,0],[0,0,1,0,0,1,0,0,0,0,0],[0,1,0,1,0,0,1,0,0,0,0],[0,0,0,0,0,0,0,1,0,1,1],[0,0,0,0,0,0,0,0,1,0,0],[0,0,1,0,0,0,0,1,0,0,0]];
const monitor = {"lugar":"cupo","m0":4,"transiciones":["t_iniciar_past","t_embotellar"],"descripcion":"Cupo_frio consume en t_iniciar_past y devuelve en t_embotellar."};
const invariantes = [{"nombre":"Tanques","pesos":{"tanque":1,"lote_past":1,"lote_enfr":1},"valor":3},{"nombre":"Vapor","pesos":{"vapor":1,"lote_past":1},"valor":1},{"nombre":"Frío","pesos":{"frio":1,"lote_enfr":1},"valor":1},{"nombre":"Embotelladora","pesos":{"emb_lista":1,"emb_parada":1},"valor":1},{"nombre":"Cupo del cuarto frío","pesos":{"cupo":1,"lote_past":1,"lote_enfr":1,"cuarto":1},"valor":4},{"nombre":"Lote total (sin llegadas)","pesos":{"leche":1,"lote_past":1,"lote_enfr":1,"cuarto":1,"botellas":1},"valor":6}];
const deadlock = {"marcado":{"tanque":1,"lote_past":1,"lote_enfr":1,"cuarto":4,"emb_parada":1},"secuencia":["t_iniciar_past","t_fin_past","t_iniciar_past","t_fin_enfr","t_fin_past","t_iniciar_past","t_fin_enfr","t_fin_past","t_iniciar_past","t_fin_enfr","t_fin_past","t_iniciar_past","t_fin_enfr","t_fin_past","t_iniciar_past","t_parar_emb"],"secuenciaTexto":"i f i d f i d f i d f i d f i parar_emb","prevencion":"Cupo_frio (M0 = 4): t_iniciar_past lo consume y t_embotellar lo devuelve. Invariante: Cupo_frio + Lote_past + Lote_enfr + Cuarto_frio = 4. El marcado muerto exigiría 6 lotes (1 + 1 + 4) en ese circuito, así que es inalcanzable con el monitor.","reglaCorta":"No iniciar más lotes que el cupo del cuarto frío: 4 en total."};
const analisis = {"sinPrevencion":{"marcados":160,"deadlocks":1},"conPrevencion":{"marcados":146,"deadlocks":0},"conflicto":"Vapor_disp es compartido por t_iniciar_past y t_arrancar_emb.","andJoin":"t_iniciar_past necesita Leche_cruda + Tanque_libre + Vapor_disp (+ Cupo_frio con monitor)."};
const redJson = {
  nombre: nombre$1,
  descripcion: descripcion$1,
  lugares,
  transiciones: transiciones$1,
  pre,
  post,
  monitor,
  invariantes,
  deadlock,
  analisis,
};

const nombre = "Reparacion_CIP";
const descripcion = "DFA del lenguaje de reparación CIP. ^P(SE)+AEZ$: preenjuague, una o más rondas de soda cáustica + enjuague, ácido, enjuague y sanitización. En JFLAP se agrega un estado trampa para que el DFA sea completo.";
const regex = "^P(SE)+AEZ$";
const simbolos = ["P","S","E","A","Z"];
const estados = ["q0","q1","q2","q3","q4","q5","q6","Trampa"];
const inicial = "q0";
const finales = ["q6"];
const trampa = "Trampa";
const transiciones = [["q0","P","q1"],["q1","S","q2"],["q2","E","q3"],["q3","S","q2"],["q3","A","q4"],["q4","E","q5"],["q5","Z","q6"]];
const descripcionSimbolos = {"P":"Preenjuague","S":"Soda cáustica","E":"Enjuague","A":"Ácido","Z":"Sanitizar"};
const posiciones = {"q0":[40,120],"q1":[130,120],"q2":[220,120],"q3":[310,120],"q4":[400,120],"q5":[490,120],"q6":[580,120],"Trampa":[310,230]};
const reparacionJson = {
  nombre,
  descripcion,
  regex,
  simbolos,
  estados,
  inicial,
  finales,
  trampa,
  transiciones,
  descripcionSimbolos,
  posiciones,
};

// Orquestador del juego: une el núcleo formal (src/sed/) con la vista y el reloj.
// No importa Phaser. Cada cambio de estado de un tanque pasa por su autómata y
// cada recurso se mueve por el disparo de una transición de la red de Petri.

const NOMBRES = ['Tanque 1', 'Tanque 2', 'Tanque 3'];
const OPERACION = ['Llenando', 'Pasteurizando', 'Enfriando'];
const NIVELES = {
  Vacio: 0.14,
  Llenando: 0.55,
  Pasteurizando: 1,
  Enfriando: 0.94,
  Lavado_CIP: 0.34,
  Fallo: 0.28
};

class Simulador {
  constructor({ semilla = CONFIG.SEMILLA, monitorActivo = false } = {}) {
    this.emisor = new Emisor();
    this.semilla = semilla;
    this.aleatorio = new Aleatorio(semilla);
    this.reloj = new Reloj();
    this.red = new RedPetri(redJson, { monitorActivo });
    this.tanques = [0, 1, 2].map((i) => this.crearTanque(i));
    this.supervisor = new SupervisorCIP(this.tanques.map((t) => t.automata));

    this.puntuacion = 0;
    this.estadisticas = {
      botellas: 0,
      fallos: 0,
      reparaciones: 0,
      reparacionesFallidas: 0,
      intentosBloqueados: 0,
      desbordes: 0,
      deadlocksEvitados: 0,
      logros: 0
    };
    this.logros = this.crearLogros();
    this.alertas = [];
    this.log = [];
    this.tiempo = 0;
    this.activo = false;
    this.pausado = false;
    this.velocidad = 1;
    this.terminado = false;
    this.motivoFin = null;
    this.radarCache = null;
    this._radarT = -1;
    this.puntoSeguro = null;
    this._ultimoPuntoSeguro = -99;
    this.ultimoLogro = null;
    this.reparadoPrimerIntento = false;
    this.iniciar();
  }

  crearTanque(i) {
    return {
      id: `T${i + 1}`,
      numero: i + 1,
      nombre: NOMBRES[i],
      automata: new Automata(tanqueJson),
      lenguaje: new Lenguaje(reparacionJson),
      llenadoEn: -Infinity,
      pasteurizandoEn: -Infinity,
      enfriandoEn: -Infinity,
      cipEn: -Infinity,
      intentosReparacion: 0,
      ayuda: false,
      fallos: 0,
      esperandoFrio: false
    };
  }

  iniciar() {
    this.reloj.limpiar();
    this.reloj.tiempo = 0;
    this.tiempo = 0;
    this.activo = true;
    this.terminado = false;
    this.pausado = false;
    this.motivoFin = null;
    this.radarCache = null;
    this.puntoSeguro = null;
    this.reloj.programar(CONFIG.DURACION_TURNO, () => this.finalizar('tiempo'), 'turno');
    this.reloj.programar(CONFIG.TIEMPOS.llegadaLeche, () => this.llegadaLeche(), 'leche');
    this.reloj.programar(CONFIG.TIEMPOS.embotellado, () => this.embotellarAuto(), 'embotellado');
    this.reloj.programar(CONFIG.TIEMPOS.revisionFallo, () => this.revisionFallo(), 'revision');
    this.actualizarRadar();
    this.actualizarPuntoSeguro();
    this.emisor.emitir('cambio');
  }

  // ---------- bucle ----------
  actualizar(dtSegundos) {
    if (!this.activo || this.pausado) return;
    this.reloj.avanzar(dtSegundos * this.velocidad);
    this.tiempo = this.reloj.tiempo;
    if (!this.activo) return;
    if (this.verificarDeadlock()) return;
    if (this.tiempo - this._radarT >= 0.5) {
      this.actualizarRadar();
      this._radarT = this.tiempo;
    }
    this.verificarLogros();
  }

  tanque(id) {
    return this.tanques.find((t) => t.id === id || t.numero === Number(id));
  }

  pausar() {
    if (!this.activo) return;
    this.pausado = !this.pausado;
    this.emisor.emitir('pausa', this.pausado);
    this.emisor.emitir('cambio');
  }

  setVelocidad(v) {
    if (!CONFIG.VELOCIDADES.includes(v)) return;
    this.velocidad = v;
    this.emisor.emitir('velocidad', v);
    this.emisor.emitir('cambio');
  }

  // ---------- eventos del reloj ----------
  llegadaLeche() {
    if (!this.activo) return;
    const antes = this.red.M[this.red.idxLugar.get('leche')];
    const r = this.red.agregarToken('leche', 1);
    if (r.desborde && r.despues > antes) {
      this.puntuacion += CONFIG.PUNTOS.desborde;
      this.estadisticas.desbordes++;
      this.alerta(`Desborde del silo: Leche_cruda ${r.despues}/${this.red.lugares[this.red.idxLugar.get('leche')].k}. −${Math.abs(CONFIG.PUNTOS.desborde)} pts.`, 'desborde');
    }
    this.emisor.emitir('transicion', { tipo: 'llegada_leche', lugar: 'leche', antes, despues: r.despues });
    this.cambio();
    this.actualizarRadar();
    this.reloj.programar(CONFIG.TIEMPOS.llegadaLeche, () => this.llegadaLeche(), 'leche');
  }

  embotellarAuto() {
    if (!this.activo) return;
    if (this.red.habilitada('t_embotellar')) {
      const d = this.red.disparar('t_embotellar');
      this.estadisticas.botellas++;
      this.puntuacion += CONFIG.PUNTOS.botella;
      this.emisor.emitir('transicion', { tipo: 'embotellar', ...d });
      this.cambio();
      this.actualizarRadar();
      this.verificarLogros();
      this.verificarDeadlock();
    }
    if (this.activo) this.reloj.programar(CONFIG.TIEMPOS.embotellado, () => this.embotellarAuto(), 'embotellado');
  }

  revisionFallo() {
    if (!this.activo) return;
    const candidatos = this.tanques.filter((t) => t.automata.estado === 'Llenando');
    if (candidatos.length && this.aleatorio.probabilidad(CONFIG.PROBABILIDAD_FALLO)) {
      const t = this.aleatorio.elegir(candidatos);
      this.fallar(t, 'contaminacion');
    }
    this.reloj.programar(CONFIG.TIEMPOS.revisionFallo, () => this.revisionFallo(), 'revision');
  }

  fallar(t, eventoId) {
    if (!t || t.automata.estado !== 'Llenando') return false;
    t.automata.ejecutar(eventoId);
    t.fallos++;
    this.estadisticas.fallos++;
    this.puntuacion += CONFIG.PUNTOS.fallo;
    const causa = eventoId === 'contaminacion' ? 'contaminación' : 'pérdida de temperatura';
    this.alerta(`${t.nombre}: ${causa} durante el llenado → Fallo. Requiere Lavado CIP.`, 'fallo');
    this.emisor.emitir('transicion', { tipo: 'fallo', tanque: t.id, evento: eventoId });
    this.cambio();
    this.actualizarRadar();
    this.verificarLogros();
    return true;
  }

  finPasteurizacion(t) {
    if (!this.activo || t.automata.estado !== 'Pasteurizando') return;
    if (!this.red.habilitada('t_fin_past')) {
      if (!t.esperandoFrio) {
        t.esperandoFrio = true;
        this.alerta(`${t.nombre}: pasteurización retenida; Frio_disp = 0 (lo retiene otro lote en enfriamiento).`, 'espera');
      }
      this.reloj.programar(1, () => this.finPasteurizacion(t), `fin_past_${t.id}`);
      return;
    }
    t.esperandoFrio = false;
    const d = this.red.disparar('t_fin_past');
    t.automata.ejecutar('fin_past');
    t.enfriandoEn = this.reloj.tiempo;
    this.emisor.emitir('transicion', { tipo: 'fin_past', tanque: t.id, ...d });
    this.alerta(`${t.nombre}: fin de pasteurización; lote en enfriamiento.`, 'ok');
    this.cambio();
    this.actualizarRadar();
    this.verificarLogros();
    this.verificarDeadlock();
  }

  // ---------- acciones del jugador ----------
  solicitarEvento(id, eventoId) {
    if (!this.activo) return { ok: false, motivo: 'El turno terminó.' };
    if (this.pausado) return { ok: false, motivo: 'La simulación está en pausa.' };
    const t = this.tanque(id);
    if (!t) return { ok: false, motivo: 'Tanque desconocido.' };
    const a = t.automata;
    if (!a.puede(eventoId)) {
      this.alerta(`δ(${a.estado}, ${eventoId}) no está definida para ${t.nombre}.`, 'modelo');
      return { ok: false, motivo: `δ(${a.estado}, ${eventoId}) no está definida.` };
    }

    switch (eventoId) {
      case 'abrir_valvula': {
        a.ejecutar('abrir_valvula');
        t.llenadoEn = this.reloj.tiempo;
        this.alerta(`${t.nombre}: válvula abierta, llenando.`, 'ok');
        this.emisor.emitir('transicion', { tipo: 'llenar', tanque: t.id });
        break;
      }
      case 'iniciar_past': {
        const falta = t.llenadoEn + CONFIG.TIEMPOS.llenado - this.reloj.tiempo;
        if (falta > 0) {
          return { ok: false, motivo: `Llenando: faltan ${falta.toFixed(1)} s.` };
        }
        if (!this.red.habilitada('t_iniciar_past')) {
          return this.bloqueo(t, eventoId, this.red.razonNoHabilitada('t_iniciar_past').texto);
        }
        const d = this.red.disparar('t_iniciar_past');
        a.ejecutar('iniciar_past');
        t.pasteurizandoEn = this.reloj.tiempo;
        t.esperandoFrio = false;
        this.alerta(`${t.nombre}: pasteurización iniciada (Leche + Tanque_libre + Vapor + Cupo).`, 'ok');
        this.emisor.emitir('transicion', { tipo: 'iniciar_past', tanque: t.id, ...d });
        this.reloj.programar(CONFIG.TIEMPOS.pasteurizacion, () => this.finPasteurizacion(t), `fin_past_${t.id}`);
        break;
      }
      case 'descargar': {
        const falta = t.enfriandoEn + CONFIG.TIEMPOS.enfriamiento - this.reloj.tiempo;
        if (falta > 0) {
          return { ok: false, motivo: `Enfriando: faltan ${falta.toFixed(1)} s.` };
        }
        if (!this.red.habilitada('t_fin_enfr')) {
          return this.bloqueo(t, eventoId, this.red.razonNoHabilitada('t_fin_enfr').texto);
        }
        const d = this.red.disparar('t_fin_enfr');
        a.ejecutar('descargar');
        t.enfriandoEn = -Infinity;
        this.alerta(`${t.nombre}: lote descargado al cuarto frío (${this.red.M[this.red.idxLugar.get('cuarto')]}/4).`, 'ok');
        this.emisor.emitir('transicion', { tipo: 'descargar', tanque: t.id, ...d });
        break;
      }
      case 'iniciar_CIP': {
        const deshabilitados = this.supervisor.eventosDeshabilitados(t.numero - 1);
        if (deshabilitados.length) {
          return this.bloqueo(t, eventoId, deshabilitados[0].razon);
        }
        a.ejecutar('iniciar_CIP');
        t.cipEn = this.reloj.tiempo;
        t.intentosReparacion = 0;
        t.ayuda = false;
        t.lenguaje.reiniciar();
        this.alerta(`${t.nombre}: circuito CIP iniciado. Escribe la receta de reparación.`, 'ok');
        this.emisor.emitir('transicion', { tipo: 'iniciar_CIP', tanque: t.id });
        this.emisor.emitir('abrir_consola', t.id);
        break;
      }
      case 'contaminacion':
      case 'perdida_temp': {
        if (a.estado !== 'Llenando') {
          return { ok: false, motivo: 'El fallo solo se puede provocar durante el llenado.' };
        }
        return { ok: this.fallar(t, eventoId) };
      }
      default:
        return { ok: false, motivo: `El evento ${eventoId} no se solicita desde el HUD.` };
    }

    this.cambio();
    this.actualizarRadar();
    this.verificarLogros();
    this.verificarDeadlock();
    return { ok: true };
  }

  bloqueo(t, evento, razon) {
    this.estadisticas.intentosBloqueados++;
    this.puntuacion += CONFIG.PUNTOS.intentoBloqueado;
    const nombre = t?.nombre ?? 'Embotelladora';
    this.alerta(`Intento bloqueado en ${nombre}: ${razon} (−${Math.abs(CONFIG.PUNTOS.intentoBloqueado)} pts).`, 'bloqueo');
    this.emisor.emitir('bloqueado', { tanque: t?.id ?? null, evento, razon });
    this.cambio();
    return { ok: false, motivo: razon };
  }

  // ---------- consola de reparación ----------
  avanzarReparacion(id, simbolo) {
    const t = this.tanque(id);
    if (!t || t.automata.estado !== 'Lavado_CIP') return { ok: false, motivo: 'El tanque no está en Lavado_CIP.' };
    const r = t.lenguaje.avanzar(simbolo);
    this.emisor.emitir('reparacion_progreso', { tanque: t.id, ...r });
    return r;
  }

  reiniciarReparacion(id) {
    const t = this.tanque(id);
    if (!t) return;
    t.lenguaje.reiniciar();
    this.emisor.emitir('reparacion_progreso', { tanque: t.id, ...t.lenguaje.progreso() });
  }

  pedirAyuda(id) {
    const t = this.tanque(id);
    if (!t || t.ayuda) return;
    t.ayuda = true;
    this.puntuacion -= 5;
    this.alerta(`${t.nombre}: ayuda mostrada (${reparacionJson.regex}); −5 pts.`, 'info');
    this.cambio();
  }

  reparar(id, palabra) {
    const t = this.tanque(id);
    if (!t) return { ok: false, motivo: 'Tanque desconocido.' };
    if (t.automata.estado !== 'Lavado_CIP') return { ok: false, motivo: 'El tanque no está en Lavado_CIP.' };
    const validador = new Lenguaje(reparacionJson);
    const v = validador.validar(palabra);
    if (!v.coincide) {
      t.intentosReparacion++;
      this.estadisticas.reparacionesFallidas++;
      this.puntuacion += CONFIG.PUNTOS.reparacionInvalida;
      this.alerta(`${t.nombre}: CIP inválido "${v.palabra}". La máquina sigue en Lavado_CIP (−${Math.abs(CONFIG.PUNTOS.reparacionInvalida)} pts).`, 'fallo');
      this.emisor.emitir('reparacion', { tanque: t.id, palabra: v.palabra, ok: false });
      this.cambio();
      return { ok: false, motivo: 'La palabra no pertenece a L.', validacion: v };
    }
    const primero = t.intentosReparacion === 0;
    t.automata.ejecutar('CIP_ok');
    t.reparadoPrimerIntento = primero;
    this.estadisticas.reparaciones++;
    this.puntuacion += primero
      ? CONFIG.PUNTOS.reparacionPrimerIntento
      : Math.round(CONFIG.PUNTOS.reparacionPrimerIntento / 2);
    this.alerta(`${t.nombre}: CIP validado con ${v.palabra}. Tanque disponible.`, 'ok');
    if (primero) this.otorgarLogro('cip_perfecto');
    this.emisor.emitir('reparacion', { tanque: t.id, palabra: v.palabra, ok: true });
    this.emisor.emitir('transicion', { tipo: 'CIP_ok', tanque: t.id });
    this.cambio();
    this.actualizarRadar();
    this.verificarLogros();
    return { ok: true, validacion: v };
  }

  // ---------- embotelladora ----------
  pararEmbotelladora() {
    return this.accionEmbotelladora('t_parar_emb');
  }

  arrancarEmbotelladora() {
    return this.accionEmbotelladora('t_arrancar_emb');
  }

  alternarEmbotelladora() {
    if (this.red.habilitada('t_parar_emb')) return this.pararEmbotelladora();
    if (this.red.habilitada('t_arrancar_emb')) return this.arrancarEmbotelladora();
    return this.bloqueo(null, 't_arrancar_emb', this.red.razonNoHabilitada('t_arrancar_emb').texto);
  }

  accionEmbotelladora(tid) {
    if (!this.activo) return { ok: false, motivo: 'El turno terminó.' };
    if (!this.red.habilitada(tid)) {
      return this.bloqueo(null, tid, this.red.razonNoHabilitada(tid).texto);
    }
    const d = this.red.disparar(tid);
    this.alerta(
      tid === 't_parar_emb'
        ? 'Embotelladora detenida. Para arrancarla se necesita Vapor_disp.'
        : 'Embotelladora en marcha (vapor disponible).',
      'ok'
    );
    this.emisor.emitir('transicion', { tipo: tid, ...d });
    this.cambio();
    this.actualizarRadar();
    this.verificarDeadlock();
    return { ok: true };
  }

  // ---------- prevención ----------
  alternarMonitor() {
    if (!this.activo) return { ok: false, motivo: 'El turno terminó.' };
    const antes = this.radar().color;
    const activar = !this.red.monitorActivo;
    this.red.setMonitor(activar);
    this.actualizarRadar();
    if (activar) {
      this.alerta('Prevención Cupo_frio activada: se limita el circuito a 4 lotes.', 'ok');
      if (antes === 'amarillo') {
        this.estadisticas.deadlocksEvitados++;
        this.puntuacion += CONFIG.PUNTOS.deadlockEvitado;
        this.otorgarLogro('deadlock_evitado');
      }
      if (this.red.M[this.red.idxLugar.get('cuarto')] <= 2) this.otorgarLogro('guardian_frio');
    } else {
      this.alerta('Prevención Cupo_frio desactivada: el deadlock vuelve a ser alcanzable.', 'espera');
    }
    this.cambio();
    this.verificarDeadlock();
    return { ok: true, monitorActivo: this.red.monitorActivo };
  }

  // ---------- radar y punto seguro ----------
  verificarDeadlock() {
    if (!this.activo) return false;
    if (this.esDeadlockCircular(this.red.M)) {
      this.finalizar('deadlock');
      return true;
    }
    return false;
  }

  esDeadlockCircular(M = this.red.M) {
    if (!this.red.esMuerto(M)) return false;
    const v = (id) => M[this.red.idxLugar.get(id)];
    return (
      v('cuarto') >= 4 &&
      v('emb_parada') === 1 &&
      v('lote_past') + v('lote_enfr') >= 2 &&
      v('vapor') === 0 &&
      v('frio') === 0
    );
  }

  actualizarRadar() {
    const radio = explorar(this.red, this.red.M, 3);
    const muertosCirc = radio.muertos.filter((n) => this.esDeadlockCircular(n.marcado));
    const color = this.esDeadlockCircular(this.red.M) ? 'rojo' : muertosCirc.length ? 'amarillo' : 'verde';
    this.radarCache = {
      ...radio,
      muertosCirc,
      color,
      clave: this.red.M.join(','),
      monitor: this.red.monitorActivo
    };
    if (color === 'verde') this.actualizarPuntoSeguro();
    return this.radarCache;
  }

  radar() {
    if (!this.radarCache || this.radarCache.clave !== this.red.M.join(',')) {
      return this.actualizarRadar();
    }
    return this.radarCache;
  }

  actualizarPuntoSeguro() {
    if (!this.activo) return;
    if (this.tiempo - this._ultimoPuntoSeguro < 1) return;
    this._ultimoPuntoSeguro = this.tiempo;
    this.puntoSeguro = {
      tiempo: this.reloj.tiempo,
      puntuacion: this.puntuacion,
      M: [...this.red.M],
      tanques: this.tanques.map((t) => ({
        estado: t.automata.estado,
        historial: [...t.automata.historial]
      }))
    };
  }

  reintentarSeguro() {
    const p = this.puntoSeguro;
    if (!p) return false;
    this.reloj.limpiar();
    this.reloj.tiempo = p.tiempo;
    this.tiempo = p.tiempo;
    this.red.M = [...p.M];
    this.red.disparos = [];
    this.tanques.forEach((t, i) => {
      t.automata.estado = p.tanques[i].estado;
      t.automata.historial = [...p.tanques[i].historial];
      t.llenadoEn = p.tiempo - CONFIG.TIEMPOS.llenado;
      t.enfriandoEn = p.tiempo - CONFIG.TIEMPOS.enfriamiento;
      t.pasteurizandoEn = p.tiempo;
      t.intentosReparacion = 0;
      t.ayuda = false;
      t.esperandoFrio = false;
      t.lenguaje.reiniciar();
    });
    this.puntuacion = p.puntuacion;
    this.activo = true;
    this.terminado = false;
    this.pausado = false;
    this.motivoFin = null;
    this.reloj.programar(Math.max(0.1, CONFIG.DURACION_TURNO - p.tiempo), () => this.finalizar('tiempo'), 'turno');
    this.reloj.programar(CONFIG.TIEMPOS.llegadaLeche, () => this.llegadaLeche(), 'leche');
    this.reloj.programar(CONFIG.TIEMPOS.embotellado, () => this.embotellarAuto(), 'embotellado');
    this.reloj.programar(CONFIG.TIEMPOS.revisionFallo, () => this.revisionFallo(), 'revision');
    for (const t of this.tanques) {
      if (t.automata.estado === 'Pasteurizando') {
        this.reloj.programar(CONFIG.TIEMPOS.pasteurizacion, () => this.finPasteurizacion(t), `fin_past_${t.id}`);
      }
    }
    this.actualizarRadar();
    this.cambio();
    this.alerta('Reintento desde el último marcado verde del radar.', 'ok');
    return true;
  }

  // ---------- vista del HUD ----------
  eventosHUD(id) {
    const t = this.tanque(id);
    if (!t) return [];
    const a = t.automata;
    return a.eventosActivos().map((ev) => {
      let habilitado = false;
      let razon = '';
      if (!ev.controlable) {
        razon = 'Evento no controlable: ocurre solo (reloj o modelo).';
      } else if (ev.id === 'abrir_valvula') {
        habilitado = true;
        razon = 'Controlable y habilitado.';
      } else if (ev.id === 'iniciar_past') {
        const falta = t.llenadoEn + CONFIG.TIEMPOS.llenado - this.reloj.tiempo;
        if (falta > 0) {
          razon = `Llenando: faltan ${falta.toFixed(1)} s de llenado.`;
        } else {
          const r = this.red.razonNoHabilitada('t_iniciar_past');
          habilitado = r.habilitada;
          razon = r.texto;
        }
      } else if (ev.id === 'descargar') {
        const falta = t.enfriandoEn + CONFIG.TIEMPOS.enfriamiento - this.reloj.tiempo;
        if (falta > 0) {
          razon = `Enfriando: faltan ${falta.toFixed(1)} s.`;
        } else {
          const r = this.red.razonNoHabilitada('t_fin_enfr');
          habilitado = r.habilitada;
          razon = r.texto;
        }
      } else if (ev.id === 'iniciar_CIP') {
        const d = this.supervisor.eventosDeshabilitados(t.numero - 1);
        habilitado = d.length === 0;
        razon = d[0]?.razon ?? 'Circuito CIP libre.';
      } else if (ev.id === 'CIP_ok') {
        razon = 'Se dispara al validar la palabra del lenguaje de reparación.';
      }
      if (ev.id === 'perdida_temp') {
        razon = 'Evento no controlable. Puedes forzarlo desde el HUD: el tanque va a Fallo y pierde 25 puntos.';
      }
      return {
        id: ev.id,
        codigo: ev.codigo,
        nombre: ev.nombre,
        controlable: ev.controlable,
        habilitado,
        razon,
        color: !ev.controlable ? 'gris' : habilitado ? 'verde' : 'rojo'
      };
    });
  }

  puedeForzar(t) {
    return this.activo && t.automata.estado === 'Llenando';
  }

  logrosDeTanque(id) {
    return [...(this.tanque(id)?.automata.historialCodigos(10) ?? [])];
  }

  tiempoRestante() {
    return Math.max(0, CONFIG.DURACION_TURNO - this.reloj.tiempo);
  }

  resumen() {
    return {
      puntuacion: this.puntuacion,
      tiempo: this.reloj.tiempo,
      tiempoRestante: this.tiempoRestante(),
      velocidad: this.velocidad,
      monitorActivo: this.red.monitorActivo,
      activo: this.activo,
      terminado: this.terminado,
      motivo: this.motivoFin,
      estadisticas: { ...this.estadisticas },
      logros: this.logros.map((l) => ({ ...l })),
      tanques: this.tanques.map((t) => ({
        id: t.id,
        numero: t.numero,
        nombre: t.nombre,
        estado: t.automata.estado,
        nivel: NIVELES[t.automata.estado] ?? 0.2,
        marcado: t.automata.esMarcado(),
        fallos: t.fallos
      })),
      red: {
        marcado: this.red.marcado(),
        marcadoObj: this.red.marcadoObj(),
        habilitadas: this.red.habilitadas(),
        conflictos: this.red.conflictos(),
        muerto: this.red.esMuerto()
      },
      radar: this.radarCache
    };
  }

  // ---------- logros y alertas ----------
  crearLogros() {
    return [
      { id: 'primer_lote', nombre: 'Primer lote', descripcion: 'Embotella tu primer lote.', ganado: false },
      { id: 'linea_completa', nombre: 'Línea completa', descripcion: 'Ten los 3 tanques en Llenando, Pasteurizando y Enfriando a la vez.', ganado: false },
      { id: 'cip_perfecto', nombre: 'CIP perfecto', descripcion: 'Valida una reparación CIP al primer intento.', ganado: false },
      { id: 'guardian_frio', nombre: 'Guardián del frío', descripcion: 'Activa Cupo_frio antes de llenar el cuarto frío.', ganado: false },
      { id: 'sin_derrames', nombre: 'Sin derrames', descripcion: 'Termina el turno sin desbordar el silo.', ganado: false },
      { id: 'deadlock_evitado', nombre: 'Deadlock evitado', descripcion: 'Activa la prevención cuando el radar está amarillo.', ganado: false }
    ];
  }

  verificarLogros() {
    if (this.estadisticas.botellas >= 1) this.otorgarLogro('primer_lote');
    const operando = new Set(
      this.tanques.map((t) => t.automata.estado).filter((e) => OPERACION.includes(e))
    );
    if (operando.size >= 3) this.otorgarLogro('linea_completa');
  }

  otorgarLogro(id) {
    const logro = this.logros.find((l) => l.id === id);
    if (!logro || logro.ganado) return false;
    logro.ganado = true;
    this.puntuacion += CONFIG.PUNTOS.logro;
    this.estadisticas.logros++;
    this.ultimoLogro = logro;
    this.alerta(`Logro: ${logro.nombre}`, 'logro');
    this.emisor.emitir('logro', logro);
    return true;
  }

  alerta(texto, tipo = 'info') {
    const alerta = { texto, tipo, tiempo: this.reloj.tiempo, id: `${this.reloj.tiempo}-${this.alertas.length}` };
    this.alertas.push(alerta);
    if (this.alertas.length > 8) this.alertas.shift();
    this.emisor.emitir('alerta', alerta);
  }

  cambio() {
    this.emisor.emitir('cambio');
  }

  // ---------- fin ----------
  finalizar(motivo) {
    if (!this.activo) return;
    if (motivo === 'tiempo') {
      this.verificarLogros();
      if (this.estadisticas.desbordes === 0) this.otorgarLogro('sin_derrames');
    }
    if (motivo === 'deadlock') {
      this.puntuacion += CONFIG.PUNTOS.deadlock;
      this.alerta('Game over por interbloqueo: el marcado actual no habilita ninguna transición.', 'deadlock');
    }
    this.activo = false;
    this.terminado = true;
    this.motivoFin = motivo;
    this.reloj.limpiar();
    const exito = motivo === 'tiempo' && this.estadisticas.botellas >= CONFIG.VICTORIA.botellasMinimas;
    const data = {
      motivo,
      exito,
      resumen: this.resumen(),
      marcadoMuerto: this.red.marcado(),
      marcadoObj: this.red.marcadoObj(),
      secuencia: this.red.disparos.slice(-20).map((d) => d.transicion),
      prevencion: redJson.deadlock.prevencion,
      reglaCorta: redJson.deadlock.reglaCorta,
      puntoSeguro: Boolean(this.puntoSeguro)
    };
    this.emisor.emitir('fin', data);
  }

  cambiarTurno() {
    // El turno se reinicia con una instancia nueva desde la escena.
    this.activo = false;
    this.terminado = true;
    this.reloj.limpiar();
  }
}

// Entrada unificada: teclado, mouse y táctil producen las mismas acciones.

class GestorEntrada {
  constructor(escena) {
    this.escena = escena;
    this.emisor = new Emisor();
    this.arrastre = null;
    this.pinch = null;
    this._handlers = [];

    const on = (objeto, evento, fn) => {
      objeto.on(evento, fn);
      this._handlers.push({ objeto, evento, fn });
    };

    on(escena.input.keyboard, 'keydown', (event) => {
      const k = event.key;
      if (k === 'p' || k === 'P') {
        event.preventDefault?.();
        this.emisor.emitir('accion', { tipo: 'pausa' });
      } else if (k === 'i' || k === 'I') {
        event.preventDefault?.();
        this.emisor.emitir('accion', { tipo: 'inspector' });
      } else if (k === '1' || k === '2' || k === '4') {
        this.emisor.emitir('accion', { tipo: 'velocidad', valor: Number(k) });
      } else if (k === 'Escape') {
        this.emisor.emitir('accion', { tipo: 'cerrar' });
      } else if (k === 'F1') {
        event.preventDefault?.();
        this.emisor.emitir('accion', { tipo: 'fps' });
      }
    });

    on(escena.input, 'pointerdown', (pointer) => {
      const hits = escena.input.hitTestPointer(pointer) ?? [];
      const sobreFondo = hits.length === 0 || hits[0] === escena.zonaFondo;
      if (sobreFondo) {
        this.emisor.emitir('accion', { tipo: 'clicFondo' });
        this.arrastre = { x: pointer.x, y: pointer.y, movido: false };
      } else {
        this.arrastre = null;
      }
      this._actualizarPinch();
    });

    on(escena.input, 'pointermove', (pointer) => {
      if (this.arrastre && pointer.isDown) {
        const dx = pointer.x - this.arrastre.x;
        const dy = pointer.y - this.arrastre.y;
        if (Math.abs(dx) + Math.abs(dy) > 2) {
          this.arrastre.movido = true;
          this.emisor.emitir('accion', { tipo: 'camara', dx, dy });
          this.arrastre.x = pointer.x;
          this.arrastre.y = pointer.y;
        }
      }
      this._actualizarPinch();
    });

    on(escena.input, 'pointerup', () => {
      this.arrastre = null;
      this.pinch = null;
    });

    on(escena.input, 'wheel', (pointer, objetos, dx, dy) => {
      this.emisor.emitir('accion', { tipo: 'zoom', delta: dy });
    });
  }

  _actualizarPinch() {
    const punteros = this.escena.input.manager?.pointers ?? [];
    const activos = punteros.filter((p) => p && p.isDown);
    if (activos.length < 2) return;
    const distancia = Math.hypot(activos[0].x - activos[1].x, activos[0].y - activos[1].y);
    if (this.pinch == null) {
      this.pinch = distancia;
    } else {
      const delta = distancia - this.pinch;
      if (Math.abs(delta) > 3) {
        this.emisor.emitir('accion', { tipo: 'zoom', delta: -delta * 0.8 });
        this.pinch = distancia;
      }
    }
  }

  on(fn) {
    return this.emisor.on('accion', fn);
  }

  destruir() {
    for (const { objeto, evento, fn } of this._handlers) objeto.off(evento, fn);
    this._handlers = [];
    this.emisor.limpiar();
  }
}

const OX = 480;
const OY = 100;
const CELDAS = {
  silo: { x: 1, y: 7 },
  t1: { x: 5, y: 2 },
  t2: { x: 3, y: 6 },
  t3: { x: 12, y: 2 },
  caldera: { x: 2, y: 9 },
  chiller: { x: 5, y: 10 },
  embotelladora: { x: 9, y: 7 },
  cuarto: { x: 13, y: 11 }
};

const pos = (c) => aPantallaConOffset(c.x + 0.5, c.y + 0.5, 0, OX, OY);
const prof = (c, z = 0) => profundidad(c.x + 0.5, c.y + 0.5, z);

class Planta extends Phaser.Scene {
  constructor() {
    super('Planta');
  }

  create() {
    this.cameras.main.setBackgroundColor(hex(PALETA.fondo));
    this.cameras.main.setBounds(-60, -50, 1080, 660);
    this.sim = new Simulador({ monitorActivo: false });
    this.niveles = { T1: 0.14, T2: 0.14, T3: 0.14 };
    this.estadosPrevios = { T1: 'Vacio', T2: 'Vacio', T3: 'Vacio' };
    this.tanqueSeleccionado = null;
    this.fpsVisible = false;
    this.ultimoTiempoRadar = -1;

    this.crearTexturas();
    this.crearSuelo();
    this.crearMaquinas();
    this.crearZonas();
    this.crearParticulas();
    this.crearHUDJuego();
    this.conectarEventos();
    this.crearEntrada();
    this.actualizarVista();
    this.crearTextoFPS();

    this.events.once('shutdown', () => {
      this.gestor?.destruir();
    });
  }

  // ---------- mundo ----------
  crearTexturas() {
    if (this.textures.exists('vapor')) return;
    const g = this.make.graphics({ x: 0, y: 0, add: false });
    g.fillStyle(0xffffff, 1);
    g.fillCircle(8, 8, 8);
    g.generateTexture('vapor', 16, 16);
    g.clear();
    g.fillStyle(0xffffff, 1);
    g.fillCircle(10, 10, 10);
    g.generateTexture('brillo', 20, 20);
    g.destroy();
  }

  crearSuelo() {
    const g = this.add.graphics().setDepth(-100);
    dibujarSuelo(g, 14, OX, OY);
    const muros = this.add.graphics().setDepth(-90);
    dibujarMuros(muros, 14, OX, OY, 62);

    // tuberías y conductos
    const p = this.add.graphics().setDepth(-40);
    const silo = pos(CELDAS.silo);
    const t1 = pos(CELDAS.t1);
    const t2 = pos(CELDAS.t2);
    const t3 = pos(CELDAS.t3);
    const caldera = pos(CELDAS.caldera);
    const chiller = pos(CELDAS.chiller);
    const emb = pos(CELDAS.embotelladora);
    const cuarto = pos(CELDAS.cuarto);

    p.lineStyle(7, PALETA.metalClaro, 0.55);
    p.lineBetween(silo.x + 28, silo.y - 30, t1.x - 30, t1.y - 20);
    p.lineBetween(silo.x + 18, silo.y - 22, t2.x - 10, t2.y - 24);
    p.lineBetween(silo.x + 36, silo.y - 34, t3.x - 20, t3.y - 20);
    p.lineBetween(caldera.x + 40, caldera.y - 30, t2.x + 20, t2.y - 10);
    p.lineBetween(caldera.x + 42, caldera.y - 24, t3.x - 34, t3.y - 4);
    p.lineStyle(5, PALETA.frio, 0.45);
    p.lineBetween(chiller.x + 44, chiller.y - 40, t1.x - 10, t1.y - 8);
    p.lineBetween(chiller.x + 48, chiller.y - 34, t2.x + 30, t2.y - 6);
    p.lineStyle(5, PALETA.metalClaro, 0.45);
    p.lineBetween(t1.x + 20, t1.y + 2, emb.x - 60, emb.y - 8);
    p.lineBetween(t2.x + 20, t2.y + 2, emb.x - 50, emb.y - 4);
    p.lineBetween(t3.x + 10, t3.y + 2, emb.x - 70, emb.y);
    p.lineBetween(emb.x + 30, emb.y + 6, cuarto.x - 60, cuarto.y - 8);
    p.lineStyle(3, PALETA.metal, 0.35);
    p.lineBetween(silo.x, silo.y - 150, silo.x + 30, silo.y - 170);
  }

  crearMaquinas() {
    this.graficos = {};
    this.textos = {};

    const crear = (clave, celda, anchoZona = 100, altoZona = 110, zonaY = -50) => {
      const p = pos(celda);
      const g = this.add.graphics().setDepth(prof(celda, 2));
      const eta = texto(this, p.x, p.y + 14, '', {
        fontSize: '11px',
        color: hex(PALETA.texto),
        align: 'center'
      }).setOrigin(0.5, 0).setDepth(prof(celda, 3));
      eta.setShadow(0, 1, '#000000', 3);
      this.graficos[clave] = g;
      this.textos[clave] = eta;
      return { p, g, eta };
    };

    crear('silo', CELDAS.silo, 110, 170, -70);
    crear('t1', CELDAS.t1, 96, 110, -54);
    crear('t2', CELDAS.t2, 96, 110, -54);
    crear('t3', CELDAS.t3, 96, 110, -54);
    crear('caldera', CELDAS.caldera, 120, 100, -46);
    crear('chiller', CELDAS.chiller, 110, 100, -46);
    crear('embotelladora', CELDAS.embotelladora, 160, 100, -42);
    crear('cuarto', CELDAS.cuarto, 170, 120, -56);

    const pEmb = pos(CELDAS.embotelladora);
    this.textos.embotelladora.setPosition(pEmb.x - 96, pEmb.y - 46).setOrigin(0.5, 0);
    const pCuarto = pos(CELDAS.cuarto);
    this.textos.cuarto.setPosition(pCuarto.x + 84, pCuarto.y - 10).setOrigin(0, 0.5);

    this.tokens = this.add.graphics().setDepth(260);
    this.zonas = {};
  }

  crearZonas() {
    const crearZona = (clave, celda, ancho, alto, y, onClick) => {
      const p = pos(celda);
      const zona = this.add.zone(p.x, p.y + y, ancho, alto)
        .setDepth(prof(celda, 8))
        .setInteractive({ useHandCursor: true });
      zona.on('pointerdown', onClick);
      this.zonas[clave] = zona;
      return zona;
    };

    crearZona('T1', CELDAS.t1, 96, 108, -52, () => this.abrirHUD('T1'));
    crearZona('T2', CELDAS.t2, 96, 108, -52, () => this.abrirHUD('T2'));
    crearZona('T3', CELDAS.t3, 96, 108, -52, () => this.abrirHUD('T3'));
    crearZona('embotelladora', CELDAS.embotelladora, 170, 90, -40, () => this.sim.alternarEmbotelladora());
    crearZona('cuarto', CELDAS.cuarto, 160, 90, -50, () => this.abrirInspector());

    // Fondo interactivo para arrastrar la cámara y cerrar el HUD.
    this.zonaFondo = this.add.rectangle(0, 0, 2000, 1200, 0x000000, 0)
      .setOrigin(0)
      .setDepth(-95)
      .setInteractive();
  }

  crearParticulas() {
    try {
      const caldera = pos(CELDAS.caldera);
      this.emisorVapor = this.add.particles(caldera.x, caldera.y - 92, 'vapor', {
        speedY: { min: -34, max: -12 },
        speedX: { min: -8, max: 8 },
        lifespan: 1400,
        scale: { start: 0.75, end: 0 },
        alpha: { start: 0.35, end: 0 },
        frequency: 520,
        quantity: 1,
        blendMode: 'ADD'
      });
      this.emisorVapor.setDepth(prof(CELDAS.caldera, 6));
    } catch {
      this.emisorVapor = null;
    }
  }

  crearHUDJuego() {
    if (this.scene.isActive('HUDJuego')) this.scene.stop('HUDJuego');
    this.scene.launch('HUDJuego', { simulador: this.sim });
    this.scene.bringToTop('HUDJuego');
  }

  crearTextoFPS() {
    this.fpsTexto = texto(this, 12, 78, '', {
      fontSize: '10px',
      color: hex(PALETA.textoSuave),
      fontFamily: 'Consolas, monospace'
    }).setDepth(3000).setVisible(false);
  }

  // ---------- eventos del simulador ----------
  conectarEventos() {
    const sim = this.sim;
    this.suscripciones = [];
    const on = (evento, fn) => this.suscripciones.push(sim.emisor.on(evento, fn));
    on('cambio', () => this.actualizarVista());
    on('transicion', (data) => {
      this.animarTransicion(data);
      if (data.tipo === 'embotellar') sonido.botella();
      else if (data.tipo === 'fallo') sonido.fallo();
      else sonido.transicion();
    });
    on('bloqueado', () => {
      this.cameras.main.shake(180, 0.006);
      this.destelloPantalla(PALETA.fallo, 0.16);
      sonido.bloqueado();
    });
    on('logro', () => {
      this.destelloPantalla(PALETA.acento, 0.12);
      sonido.logro();
    });
    on('alerta', (a) => {
      if (a.tipo === 'fallo' || a.tipo === 'desborde') this.cameras.main.shake(140, 0.004);
    });
    on('fin', (data) => {
      if (data.motivo === 'deadlock') sonido.deadlock();
      else if (data.exito) sonido.victoria();
      else sonido.transicion();
      this.terminar(data);
    });
    on('abrir_consola', (id) => this.abrirHUD(id));
    on('pausa', (pausado) => {
      if (pausado) this.cameras.main.flash(120, 20, 30, 40);
    });
  }

  // ---------- vista ----------
  actualizarVista() {
    if (!this.sim) return;
    const M = this.sim.red.M;
    const idx = (id) => this.sim.red.idxLugar.get(id);

    // Silo
    this.graficos.silo.clear();
    const silo = pos(CELDAS.silo);
    dibujarSilo(this.graficos.silo, silo.x, silo.y, M[idx('leche')], this.sim.red.lugares[idx('leche')].k);
    const kLeche = this.sim.red.lugares[idx('leche')].k;
    this.textos.silo.setText(`Silo de leche\n${M[idx('leche')]}/${kLeche}`);
    this.textos.silo.setColor(hex(M[idx('leche')] > kLeche ? PALETA.fallo : PALETA.leche));

    // Tanques
    for (let i = 1; i <= 3; i++) {
      const id = `T${i}`;
      const clave = `t${i}`;
      const t = this.sim.tanque(id);
      const celda = CELDAS[clave];
      const p = pos(celda);
      const estado = t.automata.estado;
      this.graficos[clave].clear();
      dibujarTanque(
        this.graficos[clave],
        p.x,
        p.y,
        estado,
        this.niveles[id],
        this.scene.isActive('HUDMaquina') && this.tanqueSeleccionado === id
      );
      this.textos[clave].setText(`${t.nombre}\n${estado}`);
      this.textos[clave].setColor(hex(colorEstado(estado)));
    }

    // Caldera y frío
    const caldera = pos(CELDAS.caldera);
    this.graficos.caldera.clear();
    dibujarCaldera(this.graficos.caldera, caldera.x, caldera.y, M[idx('vapor')] > 0);
    this.textos.caldera.setText(`Caldera\nVapor: ${M[idx('vapor')]}/1`);
    this.textos.caldera.setColor(hex(M[idx('vapor')] > 0 ? PALETA.espera : PALETA.textoSuave));

    const chiller = pos(CELDAS.chiller);
    this.graficos.chiller.clear();
    dibujarChiller(this.graficos.chiller, chiller.x, chiller.y, M[idx('frio')] > 0);
    this.textos.chiller.setText(`Bomba de frío\nFrio: ${M[idx('frio')]}/1`);
    this.textos.chiller.setColor(hex(M[idx('frio')] > 0 ? PALETA.frio : PALETA.textoSuave));

    // Embotelladora
    const emb = pos(CELDAS.embotelladora);
    const enMarcha = M[idx('emb_lista')] > 0;
    this.graficos.embotelladora.clear();
    dibujarEmbotelladora(this.graficos.embotelladora, emb.x, emb.y, enMarcha ? 'Emb_lista' : 'Emb_parada');
    this.textos.embotelladora.setText(`Embotelladora\n${enMarcha ? 'En marcha' : 'Detenida'}`);
    this.textos.embotelladora.setColor(hex(enMarcha ? PALETA.operacion : PALETA.fallo));

    // Cuarto frío
    const cuarto = pos(CELDAS.cuarto);
    const kCuarto = this.sim.red.lugares[idx('cuarto')].k;
    this.graficos.cuarto.clear();
    dibujarCuartoFrio(this.graficos.cuarto, cuarto.x, cuarto.y, M[idx('cuarto')], kCuarto);
    this.textos.cuarto.setText(`Cuarto frío\n${M[idx('cuarto')]}/${kCuarto}`);
    this.textos.cuarto.setColor(hex(M[idx('cuarto')] >= kCuarto ? PALETA.fallo : PALETA.frio));

    // Tokens físicos
    this.tokens.clear();
    const t1 = pos(CELDAS.t1);
    const t2 = pos(CELDAS.t2);
    const t3 = pos(CELDAS.t3);
    const posT = { T1: t1, T2: t2, T3: t3 };
    for (const t of this.sim.tanques) {
      const p = posT[t.id];
      if (t.automata.estado === 'Pasteurizando') dibujarToken(this.tokens, 'lote', p.x + 30, p.y - 30, 1);
      if (t.automata.estado === 'Enfriando') dibujarToken(this.tokens, 'lote', p.x + 30, p.y - 30, 1);
    }
    if (M[idx('vapor')] > 0) dibujarToken(this.tokens, 'vapor', caldera.x, caldera.y - 100, 1.2);
    if (M[idx('frio')] > 0) dibujarToken(this.tokens, 'frio', chiller.x + 30, chiller.y - 88, 1);
    const cupo = M[idx('cupo')];
    for (let i = 0; i < cupo; i++) {
      dibujarToken(this.tokens, 'cupo', cuarto.x - 96 + i * 16, cuarto.y - 18, 0.75);
    }
    const botellas = Math.min(8, M[idx('botellas')]);
    for (let i = 0; i < botellas; i++) {
      dibujarToken(this.tokens, 'botella', emb.x + 74 + (i % 2) * 10, emb.y - 14 - Math.floor(i / 2) * 12, 0.7);
    }
  }

  // ---------- animaciones ----------
  crearTokenViajero(tipo, x1, y1, x2, y2, duracion = 850, escala = 1) {
    const g = this.add.graphics().setDepth(280);
    dibujarToken(g, tipo, 0, 0, escala);
    g.setPosition(x1, y1);
    this.tweens.add({
      targets: g,
      x: x2,
      y: y2,
      alpha: 0,
      duration: duracion,
      ease: 'Sine.easeInOut',
      onComplete: () => g.destroy()
    });
    return g;
  }

  animarTransicion(data) {
    if (!data) return;
    const tankPos = { T1: pos(CELDAS.t1), T2: pos(CELDAS.t2), T3: pos(CELDAS.t3) };
    const silo = pos(CELDAS.silo);
    const caldera = pos(CELDAS.caldera);
    const chiller = pos(CELDAS.chiller);
    const emb = pos(CELDAS.embotelladora);
    const cuarto = pos(CELDAS.cuarto);
    const tp = tankPos[data.tanque] ?? pos(CELDAS.t1);

    switch (data.tipo) {
      case 'llegada_leche':
        this.crearTokenViajero('leche', silo.x - 30, silo.y - 132, silo.x - 30, silo.y - 30, 700, 0.9);
        break;
      case 'llenar':
        this.crearTokenViajero('leche', silo.x + 20, silo.y - 40, tp.x - 10, tp.y - 30, 700, 0.8);
        break;
      case 'iniciar_past':
        this.crearTokenViajero('leche', silo.x + 22, silo.y - 40, tp.x - 8, tp.y - 40, 700, 0.8);
        this.crearTokenViajero('vapor', caldera.x + 30, caldera.y - 60, tp.x + 10, tp.y - 60, 900, 0.9);
        this.explosionVapor(tp.x, tp.y - 70, 5);
        break;
      case 'fin_past':
        this.crearTokenViajero('vapor', tp.x, tp.y - 80, caldera.x, caldera.y - 70, 900, 0.8);
        this.explosionVapor(tp.x, tp.y - 80, 4);
        break;
      case 'descargar':
        this.crearTokenViajero('lote', tp.x + 20, tp.y - 30, cuarto.x - 40, cuarto.y - 40, 950, 1);
        this.crearTokenViajero('frio', chiller.x + 20, chiller.y - 50, tp.x, tp.y - 30, 900, 0.7);
        break;
      case 'embotellar':
        this.crearTokenViajero('lote', cuarto.x - 40, cuarto.y - 50, emb.x + 30, emb.y - 30, 850, 1);
        this.crearTokenViajero('botella', emb.x + 30, emb.y - 30, emb.x + 80, emb.y - 10, 700, 0.8);
        this.puntosFlotantes(emb.x + 40, emb.y - 70, `+${CONFIG.PUNTOS.botella}`, PALETA.botella);
        break;
      case 't_parar_emb':
      case 't_arrancar_emb':
        this.destello(emb.x + 66, emb.y - 54, 24, data.tipo === 't_parar_emb' ? PALETA.fallo : PALETA.operacion);
        break;
      case 'fallo':
        this.destello(tp.x, tp.y - 50, 42, PALETA.fallo);
        this.puntosFlotantes(tp.x, tp.y - 90, `−${Math.abs(CONFIG.PUNTOS.fallo)}`, PALETA.fallo);
        break;
      case 'iniciar_CIP':
        this.destello(tp.x, tp.y - 50, 42, PALETA.mantenimiento);
        this.burbujas(tp.x, tp.y - 60);
        break;
      case 'CIP_ok':
        this.destello(tp.x, tp.y - 50, 50, PALETA.operacion);
        this.burbujas(tp.x, tp.y - 70);
        break;
    }
  }

  explosionVapor(x, y, cantidad = 4) {
    if (!this.emisorVapor) return;
    try {
      this.emisorVapor.explode(cantidad, x, y);
    } catch {
      // La versión de Phaser puede no exponer explode; las partículas continuas siguen.
    }
  }

  burbujas(x, y) {
    for (let i = 0; i < 6; i++) {
      const b = this.add.circle(x + (Math.random() - 0.5) * 40, y + (Math.random() - 0.5) * 30, 3 + Math.random() * 3, PALETA.frio, 0.7).setDepth(270);
      this.tweens.add({
        targets: b,
        y: b.y - 35 - Math.random() * 25,
        alpha: 0,
        duration: 700 + Math.random() * 400,
        onComplete: () => b.destroy()
      });
    }
  }

  destello(x, y, radio, color) {
    const c = this.add.circle(x, y, radio, color, 0.25).setDepth(265);
    this.tweens.add({
      targets: c,
      scale: 1.8,
      alpha: 0,
      duration: 500,
      onComplete: () => c.destroy()
    });
  }

  puntosFlotantes(x, y, textoPunto, color) {
    const t = texto(this, x, y, textoPunto, {
      fontSize: '14px',
      color: hex(color),
      fontStyle: 'bold'
    }).setOrigin(0.5).setDepth(290);
    this.tweens.add({
      targets: t,
      y: y - 34,
      alpha: 0,
      duration: 900,
      onComplete: () => t.destroy()
    });
  }

  destelloPantalla(color, alpha = 0.12) {
    const r = this.add.rectangle(0, 0, 960, 540, color, alpha).setOrigin(0).setDepth(2959);
    this.tweens.add({ targets: r, alpha: 0, duration: 450, onComplete: () => r.destroy() });
  }

  // ---------- paneles ----------
  abrirHUD(id) {
    if (this.scene.isActive('Inspector')) return;
    if (this.scene.isActive('HUDMaquina')) this.scene.stop('HUDMaquina');
    this.tanqueSeleccionado = id;
    this.actualizarVista();
    this.scene.launch('HUDMaquina', { simulador: this.sim, tanqueId: id });
    this.scene.bringToTop('HUDMaquina');
  }

  abrirInspector() {
    if (this.scene.isActive('Inspector')) return;
    this.scene.launch('Inspector', { simulador: this.sim });
    this.scene.bringToTop('Inspector');
  }

  cerrarHUD() {
    if (this.scene.isActive('HUDMaquina')) this.scene.stop('HUDMaquina');
    this.tanqueSeleccionado = null;
    this.actualizarVista();
  }

  terminar(data) {
    this.scene.launch('Resultados', { simulador: this.sim, data });
    this.scene.bringToTop('Resultados');
    this.scene.pause();
  }

  // ---------- entrada ----------
  crearEntrada() {
    this.gestor = new GestorEntrada(this);
    this.gestor.on((accion) => this.ejecutarAccion(accion));
    this.input.on('pointerdown', () => sonido.asegurar());
    this.input.keyboard.on('keydown', () => sonido.asegurar());
  }

  consolaAbierta() {
    const hud = this.scene.get('HUDMaquina');
    return this.scene.isActive('HUDMaquina') && hud?.consolaActiva;
  }

  ejecutarAccion(accion) {
    switch (accion.tipo) {
      case 'pausa':
        if (this.consolaAbierta()) return;
        this.sim.pausar();
        break;
      case 'inspector':
        this.abrirInspector();
        break;
      case 'velocidad':
        this.sim.setVelocidad(accion.valor);
        break;
      case 'cerrar':
        if (this.scene.isActive('HUDMaquina')) this.cerrarHUD();
        break;
      case 'fps':
        this.fpsVisible = !this.fpsVisible;
        this.fpsTexto?.setVisible(this.fpsVisible);
        break;
      case 'clicFondo':
        if (this.scene.isActive('HUDMaquina')) this.cerrarHUD();
        break;
      case 'camara':
        this.cameras.main.scrollX -= accion.dx / this.cameras.main.zoom;
        this.cameras.main.scrollY -= accion.dy / this.cameras.main.zoom;
        break;
      case 'zoom': {
        const z = Phaser.Math.Clamp(this.cameras.main.zoom - accion.delta * 0.0015, 0.85, 1.8);
        this.cameras.main.setZoom(z);
        break;
      }
    }
  }

  update(time, delta) {
    if (!this.sim) return;
    this.sim.actualizar(delta / 1000);

    // Niveles de los tanques con easing
    let redibujar = false;
    for (let i = 1; i <= 3; i++) {
      const id = `T${i}`;
      const t = this.sim.tanque(id);
      const objetivo = NIVELES[t.automata.estado] ?? 0.2;
      const diferencia = objetivo - this.niveles[id];
      if (Math.abs(diferencia) > 0.001) {
        this.niveles[id] += diferencia * 0.12;
        redibujar = true;
      }
      if (this.estadosPrevios[id] !== t.automata.estado) {
        this.estadosPrevios[id] = t.automata.estado;
        redibujar = true;
      }
    }
    if (redibujar) this.actualizarVista();

    if (this.scene.isActive('HUDMaquina') === false && this.tanqueSeleccionado) {
      this.tanqueSeleccionado = null;
      this.actualizarVista();
    }

    if (this.fpsTexto) {
      const fps = Math.round(this.game.loop.actualFps);
      const restante = this.sim.tiempoRestante();
      this.fpsTexto.setText(
        `F1  fps: ${fps}  ·  sim: ${this.sim.reloj.tiempo.toFixed(1)} s  ·  restante: ${restante.toFixed(0)} s  ·  x${this.sim.velocidad}${this.sim.pausado ? '  · PAUSA' : ''}`
      );
    }
  }
}

const NOMBRES_CORTOS = {
  leche: 'Leche_cruda',
  tanque: 'Tanque_libre',
  vapor: 'Vapor_disp',
  frio: 'Frio_disp',
  lote_past: 'Lote_past',
  lote_enfr: 'Lote_enfr',
  cuarto: 'Cuarto_frio',
  emb_lista: 'Emb_lista',
  emb_parada: 'Emb_parada',
  botellas: 'Botellas',
  cupo: 'Cupo_frio'
};

const COLOR_ALERTA = {
  fallo: PALETA.fallo,
  desborde: PALETA.fallo,
  deadlock: PALETA.fallo,
  bloqueo: 0xf08a3c,
  espera: PALETA.espera,
  ok: PALETA.operacion,
  logro: PALETA.acento,
  info: PALETA.textoSuave,
  modelo: PALETA.fallo
};

class HUDJuego extends Phaser.Scene {
  constructor() {
    super('HUDJuego');
  }

  init(data) {
    this.sim = data.simulador;
    this.suscripciones = [];
  }

  create() {
    this.scene.setVisible(true);
    this.crearPaneles();
    this.crearBotones();
    this.crearTextos();
    this.crearRadar();
    this.crearAlertas();
    this.crearToast();
    this.conectarEventos();
    this.actualizar(true);
    this.events.once('shutdown', () => {
      for (const off of this.suscripciones) off();
      this.suscripciones = [];
    });
  }

  crearPaneles() {
    panel(this, 8, 8, 230, 66);
    panel(this, 248, 8, 280, 58);
    panel(this, 760, 8, 192, 124);
    panel(this, 8, 376, 258, 156);
    panel(this, 694, 376, 258, 156);
  }

  crearTextos() {
    this.turnoTexto = texto(this, 20, 14, 'TURNO 1 / 1', {
      fontSize: '10px',
      color: hex(PALETA.acento)
    });
    this.relojTexto = texto(this, 20, 28, '03:00', {
      fontSize: '24px',
      color: hex(PALETA.leche),
      fontFamily: MONO,
      fontStyle: 'bold'
    });
    this.estadoTexto = texto(this, 20, 58, 'x1 · en marcha', {
      fontSize: '10px',
      color: hex(PALETA.textoSuave)
    });

    texto(this, 260, 14, 'PUNTAJE', {
      fontSize: '10px',
      color: hex(PALETA.textoSuave)
    });
    this.puntajeTexto = texto(this, 260, 24, '0', {
      fontSize: '22px',
      color: hex(PALETA.acento),
      fontFamily: MONO,
      fontStyle: 'bold'
    });
    this.lotesTexto = texto(this, 356, 30, 'Lotes 0/6', {
      fontSize: '12px',
      color: hex(PALETA.texto)
    });
    this.metaTexto = texto(this, 356, 46, 'meta: 6 lotes', {
      fontSize: '9px',
      color: hex(PALETA.textoSuave)
    });

    texto(this, 16, 382, 'TOKENS POR LUGAR', {
      fontSize: '10px',
      color: hex(PALETA.acento)
    });
    this.tokensTextos = [];
    this.sim.red.lugares.forEach((lugar, i) => {
      const col = i < 6 ? 0 : 1;
      const fila = i < 6 ? i : i - 6;
      const t = texto(this, 16 + col * 124, 400 + fila * 18, '', {
        fontSize: '9px',
        color: hex(PALETA.textoSuave),
        fontFamily: MONO
      });
      this.tokensTextos.push(t);
    });

    texto(this, 702, 382, 'ALERTAS', {
      fontSize: '10px',
      color: hex(PALETA.acento)
    });
  }

  crearBotones() {
    this.botonPausa = boton(this, 274, 82, 50, 24, 'Pausa', () => this.sim.pausar(), {
      color: PALETA.metalOscuro,
      hover: PALETA.panelBorde,
      fontSize: '10px'
    });
    this.botonesVelocidad = CONFIG.VELOCIDADES.map((v, i) =>
      boton(this, 330 + i * 36, 82, 30, 24, `${v}×`, () => this.sim.setVelocidad(v), {
        color: PALETA.metalOscuro,
        hover: PALETA.panelBorde,
        fontSize: '10px'
      })
    );
    this.botonInspector = boton(this, 476, 82, 78, 24, 'Inspector', () => this.abrirInspector(), {
      color: PALETA.metalOscuro,
      hover: PALETA.panelBorde,
      fontSize: '10px'
    });
    this.botonMonitor = boton(this, 806, 146, 92, 24, 'Cupo: OFF', () => this.sim.alternarMonitor(), {
      color: PALETA.metalOscuro,
      hover: PALETA.panelBorde,
      fontSize: '9px'
    });
    this.botonEmbotelladora = boton(this, 900, 146, 92, 24, 'Embot: ON', () => this.sim.alternarEmbotelladora(), {
      color: PALETA.metalOscuro,
      hover: PALETA.panelBorde,
      fontSize: '9px'
    });
    this.botonCerrarResultados = null;
  }

  crearRadar() {
    this.radarTitulo = texto(this, 772, 16, 'RADAR DEL ÁRBOL', {
      fontSize: '10px',
      color: hex(PALETA.acento)
    });
    this.radarEstado = texto(this, 936, 16, 'VERDE', {
      fontSize: '10px',
      color: hex(PALETA.operacion),
      fontStyle: 'bold'
    }).setOrigin(1, 0);
    this.radarBorde = this.add.graphics().setDepth(11);
    this.radarGrafico = this.add.graphics().setDepth(12);
    this.radarDetalle = texto(this, 772, 30, 'sin deadlock en 3 disparos', {
      fontSize: '8px',
      color: hex(PALETA.textoSuave)
    });
    this.radarPulse = 0;
    this.radarClave = null;
  }

  crearAlertas() {
    this.alertasTextos = [];
    for (let i = 0; i < 3; i++) {
      const t = texto(this, 702, 400 + i * 42, '', {
        fontSize: '9px',
        color: hex(PALETA.textoSuave),
        wordWrap: { width: 240 }
      });
      this.alertasTextos.push(t);
    }
  }

  crearToast() {
    this.toastFondo = this.add.rectangle(480, 104, 300, 40, PALETA.panel, 0.96)
      .setStrokeStyle(1.5, PALETA.acento, 0.8)
      .setDepth(20)
      .setAlpha(0);
    this.toastTexto = texto(this, 480, 104, '', {
      fontSize: '12px',
      color: hex(PALETA.acento),
      align: 'center'
    }).setOrigin(0.5).setDepth(21).setAlpha(0);
  }

  conectarEventos() {
    this.suscripciones.push(this.sim.emisor.on('cambio', () => this.actualizar(false)));
    this.suscripciones.push(this.sim.emisor.on('logro', (logro) => this.mostrarToast(logro.nombre)));
    this.suscripciones.push(this.sim.emisor.on('alerta', () => this.actualizarAlertas()));
    this.suscripciones.push(this.sim.emisor.on('fin', () => this.actualizar(false)));
  }

  abrirInspector() {
    if (this.scene.isActive('Inspector')) return;
    this.scene.launch('Inspector', { simulador: this.sim });
    this.scene.bringToTop('Inspector');
  }

  mostrarToast(nombre) {
    this.toastTexto.setText(`Logro: ${nombre}`);
    this.toastFondo.setAlpha(1);
    this.toastTexto.setAlpha(1);
    this.toastFondo.y = 96;
    this.toastTexto.y = 96;
    this.tweens.add({
      targets: [this.toastFondo, this.toastTexto],
      y: 112,
      duration: 350,
      ease: 'Back.easeOut'
    });
    this.tweens.add({
      targets: [this.toastFondo, this.toastTexto],
      alpha: 0,
      delay: 1900,
      duration: 500
    });
  }

  actualizar(inicial = false) {
    const r = this.sim.resumen();
    this.turnoTexto.setText(`TURNO 1 / 1  ·  x${r.velocidad}`);
    this.relojTexto.setText(formatoTiempo(r.tiempoRestante));
    this.estadoTexto.setText(
      `${this.sim.pausado ? 'PAUSA' : 'en marcha'}  ·  ${r.estadisticas.botellas} lotes  ·  ${r.estadisticas.fallos} fallos`
    );
    this.puntajeTexto.setText(separar(r.puntuacion));
    this.lotesTexto.setText(`Lotes ${r.estadisticas.botellas}/${CONFIG.VICTORIA.botellasMinimas}`);
    this.lotesTexto.setColor(hex(r.estadisticas.botellas >= CONFIG.VICTORIA.botellasMinimas ? PALETA.operacion : PALETA.texto));

    this.botonPausa.setLabel(this.sim.pausado ? 'Seguir' : 'Pausa');
    this.botonesVelocidad.forEach((b, i) => {
      b.setColor(r.velocidad === CONFIG.VELOCIDADES[i] ? PALETA.metal : PALETA.metalOscuro);
    });
    this.botonMonitor.setLabel(`Cupo: ${r.monitorActivo ? 'ON' : 'OFF'}`);
    this.botonMonitor.setColor(r.monitorActivo ? PALETA.operacion : PALETA.metalOscuro);
    const enMarcha = r.red.marcadoObj.emb_lista > 0;
    this.botonEmbotelladora.setLabel(`Embot: ${enMarcha ? 'ON' : 'OFF'}`);
    this.botonEmbotelladora.setColor(enMarcha ? PALETA.operacion : PALETA.fallo);

    // tokens
    this.sim.red.lugares.forEach((lugar, i) => {
      const m = r.red.marcado[i];
      const t = this.tokensTextos[i];
      t.setText(`${NOMBRES_CORTOS[lugar.id] ?? lugar.nombre} ${m}/${lugar.k}`);
      let color = PALETA.texto;
      if (m === 0) color = PALETA.textoSuave;
      if (m > lugar.k && lugar.capacidad === 'desborde') color = PALETA.fallo;
      else if (m >= lugar.k && lugar.capacidad === 'estricta') color = PALETA.espera;
      t.setColor(hex(color));
    });

    this.actualizarRadar(inicial);
    this.actualizarAlertas();
  }

  actualizarRadar(inicial = false) {
    const radio = this.sim.radar();
    const color = radio.color;
    const colores = { verde: PALETA.operacion, amarillo: PALETA.espera, rojo: PALETA.fallo };
    const c = colores[color] ?? PALETA.textoSuave;
    this.radarEstado.setText(color.toUpperCase());
    this.radarEstado.setColor(hex(c));
    this.radarDetalle.setText(
      color === 'rojo'
        ? 'marcado muerto: sin transiciones'
        : color === 'amarillo'
          ? `${radio.muertosCirc.length} marcado(s) muerto(s) en ≤3`
          : 'sin deadlock en 3 disparos'
    );
    this.radarDetalle.setColor(hex(color === 'verde' ? PALETA.textoSuave : c));

    if (inicial || this.radarClave !== radio.clave) {
      this.radarClave = radio.clave;
      this.radarGrafico.clear();
      const nodos = radio.nodos;
      const posiciones = new Map();
      nodos.forEach((n, i) => {
        const x = 776 + (i % 12) * 14;
        const y = 48 + Math.floor(i / 12) * 13;
        posiciones.set(n.id, { x, y, n });
      });
      for (const e of radio.aristas) {
        const a = posiciones.get(e.de);
        const b = posiciones.get(e.a);
        if (!a || !b) continue;
        this.radarGrafico.lineStyle(1, PALETA.panelBorde, 0.55);
        this.radarGrafico.lineBetween(a.x, a.y, b.x, b.y);
      }
      for (const [id, p] of posiciones) {
        const muerto = radio.muertosCirc.some((m) => m.id === id);
        const actual = id === 'M0';
        this.radarGrafico.fillStyle(
          muerto ? PALETA.fallo : actual ? PALETA.acento : PALETA.metal,
          0.95
        );
        this.radarGrafico.fillCircle(p.x, p.y, actual ? 3.5 : 2.2);
        if (muerto) {
          this.radarGrafico.lineStyle(1, PALETA.fallo, 0.8);
          this.radarGrafico.strokeCircle(p.x, p.y, 4.5);
        }
      }
    }
    this.radarColor = color;
  }

  actualizarAlertas() {
    const ultimas = this.sim.alertas.slice(-3);
    for (let i = 0; i < 3; i++) {
      const a = ultimas[i];
      if (!a) {
        this.alertasTextos[i].setText('');
        continue;
      }
      this.alertasTextos[i].setText(`${formatoTiempo(a.tiempo)}  ${a.texto}`);
      this.alertasTextos[i].setColor(hex(COLOR_ALERTA[a.tipo] ?? PALETA.textoSuave));
    }
  }

  update(time, delta) {
    if (!this.sim) return;
    this.actualizar(false);
    this.radarPulse += delta;
    const colores = { verde: PALETA.operacion, amarillo: PALETA.espera, rojo: PALETA.fallo };
    const c = colores[this.radarColor] ?? PALETA.textoSuave;
    const alpha = this.radarColor === 'amarillo'
      ? 0.45 + 0.45 * Math.abs(Math.sin(this.radarPulse / 360))
      : 0.85;
    this.radarBorde.clear();
    this.radarBorde.lineStyle(2.5, c, alpha);
    this.radarBorde.strokeRoundedRect(760, 8, 192, 124, 10);
  }
}

const ORIGEN = { x: 552, y: 62 };
const R = 21;
const PUNTOS = tanqueJson.posiciones;
const nodoPos = (estado) => ({
  x: ORIGEN.x + (PUNTOS[estado]?.[0] ?? 180),
  y: ORIGEN.y + (PUNTOS[estado]?.[1] ?? 180)
});

const CURVAS = {
  'Enfriando>Vacio': 78,
  'Llenando>Fallo': -28,
  'Pasteurizando>Fallo': 0,
  'Enfriando>Fallo': 55,
  'Fallo>Lavado_CIP': 0,
  'Lavado_CIP>Vacio': 92,
  'Vacio>Llenando': 0,
  'Llenando>Pasteurizando': 0,
  'Pasteurizando>Enfriando': 0
};

function construirAristas() {
  const mapa = new Map();
  const lista = [];
  for (const [origen, eventoId, destino] of tanqueJson.transiciones) {
    const clave = `${origen}>${destino}`;
    if (!mapa.has(clave)) {
      const item = { origen, destino, codigos: [], clave };
      mapa.set(clave, item);
      lista.push(item);
    }
    const ev = tanqueJson.eventos.find((e) => e.id === eventoId);
    if (ev && !mapa.get(clave).codigos.includes(ev.codigo)) mapa.get(clave).codigos.push(ev.codigo);
  }
  return lista;
}

const ARISTAS = construirAristas();

class HUDMaquina extends Phaser.Scene {
  constructor() {
    super('HUDMaquina');
  }

  init(data) {
    this.sim = data.simulador;
    this.tanqueId = data.tanqueId;
    this.suscripciones = [];
    this.lenguaje = new Lenguaje(reparacionJson);
    this.palabra = '';
    this.error = '';
    this.consolaActiva = false;
    this.estadoAnterior = null;
    this.firmaGrafo = null;
    this.eventosActuales = [];
    this.eventoResaltado = null;
    this.botonesEventos = [];
    this.consolaObjetos = [];
  }

  create() {
    // Fondo interactivo del panel: aísla los clics de la planta.
    this.add.rectangle(742, 266, 428, 524, 0x000000, 0.001)
      .setDepth(0)
      .setInteractive();

    panel(this, 528, 4, 428, 524);
    this.tanque = this.sim.tanque(this.tanqueId);
    this.nombreTexto = texto(this, 552, 24, this.tanque.nombre, {
      fontSize: '17px',
      color: hex(PALETA.leche),
      fontStyle: 'bold'
    });
    this.estadoTexto = texto(this, 552, 45, this.tanque.automata.estado, {
      fontSize: '12px',
      color: hex(PALETA.textoSuave)
    });
    this.cerrarBoton = boton(this, 928, 32, 24, 24, '×', () => this.cerrar(), {
      color: PALETA.metalOscuro,
      hover: PALETA.fallo,
      fontSize: '14px'
    });

    this.graficosGrafo = this.add.graphics().setDepth(10);
    this.graficosFlash = this.add.graphics().setDepth(12);
    this.crearGrafoEstatico();
    this.crearConsola();
    this.crearTextosInferiores();
    this.conectarEventos();
    this.actualizar(true);

    this.input.keyboard.on('keydown', (event) => this.tecla(event));
    this.events.once('shutdown', () => {
      for (const off of this.suscripciones) off();
      this.suscripciones = [];
    });
  }

  crearGrafoEstatico() {
    // Etiquetas de los estados
    for (const estado of tanqueJson.estados) {
      const p = nodoPos(estado);
      texto(this, p.x, p.y + R + 5, estado, {
        fontSize: '9px',
        color: hex(PALETA.textoSuave),
        align: 'center'
      }).setOrigin(0.5, 0).setDepth(11);
    }

    // Etiquetas de las aristas (se dibujan aparte del grafo dinámico)
    this.etiquetasAristas = [];
    for (const arista of ARISTAS) {
      const a = nodoPos(arista.origen);
      const b = nodoPos(arista.destino);
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const largo = Math.hypot(dx, dy) || 1;
      const x1 = a.x + (dx / largo) * (R + 3);
      const y1 = a.y + (dy / largo) * (R + 3);
      const x2 = b.x - (dx / largo) * (R + 5);
      const y2 = b.y - (dy / largo) * (R + 5);
      const g = this.add.graphics().setDepth(9);
      const punto = dibujarArista(g, x1, y1, x2, y2, PALETA.panelBorde, CURVAS[arista.clave] ?? 0, 1.5, 0.9);
      const t = texto(this, punto.x, punto.y, arista.codigos.join(','), {
        fontSize: '8px',
        color: hex(PALETA.acento),
        fontFamily: MONO,
        align: 'center'
      }).setOrigin(0.5).setDepth(13);
      t.setShadow(0, 0, '#000000', 3);
      this.etiquetasAristas.push(t);
    }

    // Flecha de estado inicial
    const v = nodoPos('Vacio');
    const g = this.add.graphics().setDepth(13);
    g.lineStyle(1.5, PALETA.textoSuave, 0.9);
    g.lineBetween(v.x, v.y - R - 22, v.x, v.y - R - 4);
    g.fillStyle(PALETA.textoSuave, 0.9);
    g.fillTriangle(v.x, v.y - R - 2, v.x - 4, v.y - R - 9, v.x + 4, v.y - R - 9);
    texto(this, v.x + 6, v.y - R - 28, 'inicio', {
      fontSize: '8px',
      color: hex(PALETA.textoSuave)
    });
  }

  crearTextosInferiores() {
    this.historialTexto = texto(this, 552, 490, '', {
      fontSize: '9px',
      color: hex(PALETA.textoSuave),
      fontFamily: MONO,
      wordWrap: { width: 380 }
    });
    this.razonTexto = texto(this, 552, 508, '', {
      fontSize: '8px',
      color: hex(PALETA.textoSuave),
      wordWrap: { width: 380 }
    });
  }

  crearConsola() {
    const visible = false;
    this.consolaTitulo = texto(this, 552, 424, 'CONSOLA CIP · P(SE)+AEZ', {
      fontSize: '10px',
      color: hex(PALETA.acento),
      fontStyle: 'bold'
    }).setVisible(visible);
    this.consolaPalabra = texto(this, 552, 440, '', {
      fontSize: '18px',
      color: hex(PALETA.leche),
      fontFamily: MONO,
      fontStyle: 'bold'
    }).setVisible(visible);
    this.consolaDFA = texto(this, 938, 440, '', {
      fontSize: '10px',
      color: hex(PALETA.textoSuave),
      fontFamily: MONO
    }).setOrigin(1, 0).setVisible(visible);
    this.consolaError = texto(this, 552, 506, '', {
      fontSize: '9px',
      color: hex(PALETA.fallo),
      fontStyle: 'bold',
      wordWrap: { width: 380 }
    }).setVisible(visible);

    const comandos = ['P', 'S', 'E', 'A', 'Z'];
    this.consolaObjetos.push(this.consolaTitulo, this.consolaPalabra, this.consolaDFA, this.consolaError);
    comandos.forEach((s, i) => {
      const b = boton(this, 572 + i * 42, 468, 36, 24, s, () => this.agregarSimbolo(s), {
        color: PALETA.metalOscuro,
        hover: PALETA.mantenimiento,
        fontSize: '12px',
        textoColor: PALETA.leche
      });
      b.fondo.setVisible(visible);
      b.label.setVisible(visible);
      this.consolaObjetos.push(b);
    });
    const validar = boton(this, 800, 468, 70, 24, 'Validar', () => this.validar(), {
      color: PALETA.operacion,
      hover: 0x38b86c,
      fontSize: '10px',
      textoColor: PALETA.leche
    });
    const borrar = boton(this, 872, 468, 58, 24, 'Borrar', () => this.borrar(), {
      color: PALETA.metalOscuro,
      hover: PALETA.panelBorde,
      fontSize: '9px'
    });
    const ayuda = boton(this, 938, 468, 56, 24, 'Ayuda', () => this.ayuda(), {
      color: PALETA.metalOscuro,
      hover: PALETA.acento,
      fontSize: '9px'
    });
    for (const b of [validar, borrar, ayuda]) {
      b.fondo.setVisible(visible);
      b.label.setVisible(visible);
      this.consolaObjetos.push(b);
    }
    this.consolaAyuda = texto(this, 552, 490, '', {
      fontSize: '8px',
      color: hex(PALETA.acento),
      wordWrap: { width: 380 }
    }).setVisible(visible);
    this.consolaObjetos.push(this.consolaAyuda);
  }

  conectarEventos() {
    this.suscripciones.push(this.sim.emisor.on('cambio', () => this.actualizar(false)));
    this.suscripciones.push(this.sim.emisor.on('fin', () => this.actualizar(false)));
  }

  tecla(event) {
    if (!this.consolaActiva) {
      if (event.key === 'Escape') this.cerrar();
      return;
    }
    const k = event.key.toUpperCase();
    if ('PSEAZ'.includes(k) && k.length === 1) {
      event.stopPropagation?.();
      this.agregarSimbolo(k);
    } else if (k === 'ENTER') {
      event.preventDefault?.();
      this.validar();
    } else if (k === 'BACKSPACE') {
      event.preventDefault?.();
      this.borrar();
    } else if (k === 'ESCAPE') {
      this.cerrar();
    }
  }

  agregarSimbolo(s) {
    const r = this.lenguaje.avanzar(s);
    if (!r.ok) {
      const esperado = r.esperado?.length ? ` Esperado: ${r.esperado.join(' / ')}.` : '';
      this.error = `${r.motivo}${esperado}`;
    } else {
      this.error = '';
      this.palabra = this.lenguaje.palabra;
    }
    this.actualizarConsola();
  }

  borrar() {
    this.palabra = this.palabra.slice(0, -1);
    this.lenguaje.reiniciar();
    for (const ch of this.palabra) this.lenguaje.avanzar(ch);
    this.error = '';
    this.actualizarConsola();
  }

  validar() {
    if (!this.palabra) {
      this.error = 'Escribe al menos la palabra P antes de validar.';
      this.actualizarConsola();
      return;
    }
    const r = this.sim.reparar(this.tanqueId, this.palabra);
    if (r.ok) {
      this.palabra = '';
      this.error = '';
      this.lenguaje.reiniciar();
    } else {
      this.error = 'La palabra no pertenece a L; la máquina sigue en Lavado_CIP.';
    }
    this.actualizarConsola();
    this.actualizar(false);
  }

  ayuda() {
    this.sim.pedirAyuda(this.tanqueId);
    this.actualizar(false);
  }

  cerrar() {
    this.scene.stop();
  }

  actualizar(inicial = false) {
    const t = this.sim.tanque(this.tanqueId);
    if (!t) return;
    const estado = t.automata.estado;
    const eventos = this.sim.eventosHUD(this.tanqueId);
    this.eventosActuales = eventos;
    const firma = `${estado}|${t.automata.historial.length}`;
    const cambioEstado = estado !== this.estadoAnterior;
    this.estadoAnterior = estado;
    this.consolaActiva = estado === 'Lavado_CIP';

    this.nombreTexto.setText(t.nombre);
    this.estadoTexto.setText(`${estado}  ·  ${t.automata.historialCodigos(10).join(' ') || 'sin eventos'}`);
    this.estadoTexto.setColor(hex(colorEstado(estado)));

    if (inicial || cambioEstado) {
      this.lenguaje = new Lenguaje(reparacionJson);
      this.palabra = '';
      this.error = '';
    }
    if (firma !== this.firmaGrafo) {
      this.firmaGrafo = firma;
      this.dibujarGrafo(estado, t.automata.historial[t.automata.historial.length - 1]);
    }
    this.crearBotonesEventos(eventos);
    this.actualizarConsola();
    this.actualizarVisibilidad();
    this.historialTexto.setText(`Historial (10): ${t.automata.historialCodigos(10).join(' ')}`);
    const resaltado = eventos.find((e) => e.id === this.eventoResaltado);
    const rojo = eventos.find((e) => e.color === 'rojo');
    this.razonTexto.setText(resaltado?.razon ?? rojo?.razon ?? 'Todos los eventos del estado actual están disponibles.');
    this.razonTexto.setColor(hex(resaltado && !resaltado.habilitado ? PALETA.fallo : PALETA.textoSuave));
  }

  actualizarVisibilidad() {
    const visible = this.consolaActiva;
    for (const obj of this.consolaObjetos) {
      if (obj.fondo) {
        obj.fondo.setVisible(visible);
        obj.label.setVisible(visible);
      } else {
        obj.setVisible(visible);
      }
    }
    this.historialTexto.setVisible(!visible);
    this.razonTexto.setVisible(!visible);
    for (const b of this.botonesEventos) {
      b.fondo.setVisible(!visible);
      b.label.setVisible(!visible);
    }
    if (visible) {
      const t = this.sim.tanque(this.tanqueId);
      this.consolaAyuda.setText(t.ayuda ? `L = ${reparacionJson.regex}  ·  ${this.sim.tanque(this.tanqueId).ayuda ? 'ayuda mostrada (−5 pts)' : ''}` : 'P preenjuague · S soda · E enjuague · A ácido · Z sanitizar');
    }
  }

  actualizarConsola() {
    this.consolaPalabra.setText(this.palabra || '· · ·');
    this.consolaDFA.setText(`DFA: ${this.lenguaje.estado}${this.lenguaje.esValida() ? ' ✓' : ''}`);
    this.consolaDFA.setColor(hex(this.lenguaje.esValida() ? PALETA.operacion : PALETA.textoSuave));
    if (this.error) {
      this.consolaError.setText(this.error);
      this.consolaError.setColor(hex(PALETA.fallo));
    } else {
      this.consolaError.setText(`Esperado: ${this.lenguaje.siguientes().join(' / ') || '—'}`);
      this.consolaError.setColor(hex(PALETA.textoSuave));
    }
  }

  dibujarGrafo(estado, ultimoEvento) {
    this.graficosGrafo.clear();
    // nodos
    for (const q of tanqueJson.estados) {
      const p = nodoPos(q);
      dibujarNodo(this.graficosGrafo, p.x, p.y, {
        actual: q === estado,
        marcado: tanqueJson.marcados.includes(q),
        color: colorEstado(q),
        r: R
      });
    }

    // flash de la última transición
    this.graficosFlash.clear();
    if (ultimoEvento) {
      for (const [origen, eventoId, destino] of tanqueJson.transiciones) {
        if (eventoId !== ultimoEvento) continue;
        const a = nodoPos(origen);
        const b = nodoPos(destino);
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const largo = Math.hypot(dx, dy) || 1;
        const x1 = a.x + (dx / largo) * (R + 2);
        const y1 = a.y + (dy / largo) * (R + 2);
        const x2 = b.x - (dx / largo) * (R + 4);
        const y2 = b.y - (dy / largo) * (R + 4);
        const valor = { alpha: 1 };
        const curva = CURVAS[`${origen}>${destino}`] ?? 0;
        this.tweens.add({
          targets: valor,
          alpha: 0,
          duration: 500,
          onUpdate: () => {
            this.graficosFlash.clear();
            dibujarArista(this.graficosFlash, x1, y1, x2, y2, PALETA.acento, curva, 3, valor.alpha * 0.8);
          },
          onComplete: () => this.graficosFlash.clear()
        });
        break;
      }
    }
  }

  crearBotonesEventos(eventos) {
    const ids = eventos.map((e) => e.id).join(',');
    if (this.idsEventos === ids && this.botonesEventos.length === eventos.length) {
      eventos.forEach((ev, i) => {
        const b = this.botonesEventos[i];
        const color =
          ev.id === 'perdida_temp' ? 0xf08a3c :
          ev.color === 'verde' ? PALETA.operacion :
          ev.color === 'rojo' ? PALETA.fallo :
          PALETA.metalOscuro;
        b.setColor(color);
      });
      return;
    }
    for (const b of this.botonesEventos) b.destruir();
    this.botonesEventos = [];
    this.idsEventos = ids;
    eventos.forEach((ev, i) => {
      const esForzar = ev.id === 'perdida_temp';
      const color =
        esForzar ? 0xf08a3c :
        ev.color === 'verde' ? PALETA.operacion :
        ev.color === 'rojo' ? PALETA.fallo :
        PALETA.metalOscuro;
      const etiqueta = esForzar ? `${ev.codigo} · Forzar pérdida de temperatura` : `${ev.codigo} · ${ev.nombre}`;
      const b = boton(this, 742, 426 + i * 26, 380, 23, etiqueta, () => {
        if (esForzar) {
          this.sim.solicitarEvento(this.tanqueId, ev.id);
          this.actualizar(false);
          return;
        }
        if (!ev.controlable) {
          this.eventoResaltado = ev.id;
          return;
        }
        this.sim.solicitarEvento(this.tanqueId, ev.id);
        this.actualizar(false);
      }, {
        color,
        hover: esForzar ? 0xd4772a : ev.color === 'rojo' ? 0xa83232 : PALETA.panelBorde,
        fontSize: '10px',
        textoColor: PALETA.texto
      });
      b.fondo.on('pointerover', () => {
        this.eventoResaltado = ev.id;
      });
      b.fondo.on('pointerout', () => {
        this.eventoResaltado = null;
      });
      b.fondo.setDepth(14);
      b.label.setDepth(15);
      this.botonesEventos.push(b);
    });
  }

  update() {
    if (!this.sim) return;
    this.actualizar(false);
  }
}

const ABREV = ['Leche', 'Tanque', 'Vapor', 'Frio', 'LoteP', 'LoteE', 'Cuarto', 'EmbL', 'EmbP', 'Bot', 'Cupo'];

class Inspector extends Phaser.Scene {
  constructor() {
    super('Inspector');
  }

  init(data) {
    this.sim = data.simulador;
    this.tab = 'matriz';
    this.subTab = 'pre';
    this.contenido = [];
    this.resultadoPrueba = '';
  }

  create() {
    this.add.rectangle(0, 0, 960, 540, 0x000000, 0.42).setOrigin(0).setInteractive();
    panel(this, 24, 16, 912, 508);

    texto(this, 44, 28, 'INSPECTOR DE LA RED DE PETRI', {
      fontSize: '18px',
      color: hex(PALETA.leche),
      fontStyle: 'bold'
    });
    texto(this, 44, 50, 'Ecuación de estado: M_k = M_{k−1} + A^T · u_k   ·   Pre/Post de |T| × |P|   ·   A = Post − Pre', {
      fontSize: '10px',
      color: hex(PALETA.textoSuave)
    });
    boton(this, 910, 38, 26, 26, '×', () => this.cerrar(), {
      color: PALETA.metalOscuro,
      hover: PALETA.fallo,
      fontSize: '15px'
    });

    this.botonMatriz = boton(this, 90, 86, 110, 26, 'Matriz', () => this.cambiarTab('matriz'), {
      color: PALETA.operacion,
      hover: PALETA.operacion,
      fontSize: '11px'
    });
    this.botonArbol = boton(this, 210, 86, 110, 26, 'Árbol', () => this.cambiarTab('arbol'), {
      color: PALETA.metalOscuro,
      hover: PALETA.panelBorde,
      fontSize: '11px'
    });

    this.input.keyboard.on('keydown', (event) => {
      if (event.key === 'Escape' || event.key === 'i' || event.key === 'I') this.cerrar();
    });

    this.crearSubTabs();
    this.dibujar();
    this.scene.setVisible(false, 'HUDJuego');
    this.scene.pause('HUDJuego');
    this.scene.pause('Planta');
  }

  crearSubTabs() {
    this.subBotones = [
      ['pre', 'Pre'],
      ['post', 'Post'],
      ['A', 'A = Post − Pre']
    ].map(([id, label], i) => {
      const b = boton(this, 350 + i * 112, 86, 104, 24, label, () => {
        this.subTab = id;
        this.dibujar();
      }, {
        color: PALETA.metalOscuro,
        hover: PALETA.panelBorde,
        fontSize: '9px'
      });
      b.id = id;
      return b;
    });
  }

  cambiarTab(tab) {
    this.tab = tab;
    this.botonMatriz.setColor(tab === 'matriz' ? PALETA.operacion : PALETA.metalOscuro);
    this.botonArbol.setColor(tab === 'arbol' ? PALETA.operacion : PALETA.metalOscuro);
    for (const b of this.subBotones) {
      b.setEnabled(tab === 'matriz');
      b.label.setVisible(tab === 'matriz');
      b.fondo.setVisible(tab === 'matriz');
    }
    this.dibujar();
  }

  limpiar() {
    for (const obj of this.contenido) {
      if (obj?.destroy) obj.destroy();
    }
    this.contenido = [];
  }

  guardar(obj) {
    this.contenido.push(obj);
    return obj;
  }

  dibujar() {
    this.limpiar();
    for (const b of this.subBotones) {
      const activo = this.subTab === b.id;
      b.setColor(activo ? PALETA.metal : PALETA.metalOscuro);
    }
    if (this.tab === 'matriz') this.dibujarMatrices();
    else this.dibujarArbol();
  }

  dibujarMatrices() {
    const red = this.sim.red;
    const matrices = red.matrices();
    const datos =
      this.subTab === 'pre' ? matrices.pre :
      this.subTab === 'post' ? matrices.post :
      matrices.A;
    const x0 = 46;
    const y0 = 132;
    const anchoFila = 88;
    const anchoCol = 58;
    const altoFila = 23;

    const g = this.guardar(this.add.graphics());
    g.fillStyle(PALETA.metalOscuro, 1);
    g.fillRoundedRect(x0, y0 - 20, anchoFila + anchoCol * 11, 18, 4);
    for (let p = 0; p < 11; p++) {
      this.guardar(texto(this, x0 + anchoFila + p * anchoCol + anchoCol / 2, y0 - 16, ABREV[p], {
        fontSize: '8px',
        color: hex(PALETA.acento),
        fontFamily: MONO
      }).setOrigin(0.5, 0));
    }
    this.guardar(texto(this, x0 + 4, y0 - 16, 'Transición', {
      fontSize: '8px',
      color: hex(PALETA.acento),
      fontFamily: MONO
    }));

    for (let t = 0; t < red.nT; t++) {
      const y = y0 + t * altoFila;
      g.fillStyle(t % 2 === 0 ? PALETA.panel : PALETA.muro, 0.65);
      g.fillRect(x0, y, anchoFila + anchoCol * 11, altoFila);
      this.guardar(texto(this, x0 + 4, y + 6, red.transiciones[t].id.replace('t_', ''), {
        fontSize: '8px',
        color: hex(red.habilitada(t) ? PALETA.operacion : PALETA.textoSuave),
        fontFamily: MONO
      }));
      for (let p = 0; p < 11; p++) {
        const valor = datos[t][p];
        const color = valor === 0 ? PALETA.textoSuave : valor > 0 ? PALETA.operacion : PALETA.fallo;
        this.guardar(texto(this, x0 + anchoFila + p * anchoCol + anchoCol / 2, y + 6, String(valor), {
          fontSize: '9px',
          color: hex(color),
          fontFamily: MONO
        }).setOrigin(0.5, 0));
      }
    }

    const yM = y0 + red.nT * altoFila + 8;
    g.fillStyle(PALETA.metalOscuro, 0.9);
    g.fillRect(x0, yM, anchoFila + anchoCol * 11, 22);
    this.guardar(texto(this, x0 + 4, yM + 7, 'M actual', {
      fontSize: '8px',
      color: hex(PALETA.leche),
      fontFamily: MONO
    }));
    for (let p = 0; p < 11; p++) {
      const m = red.M[p];
      const k = red.lugares[p].k;
      const color = m > k ? PALETA.fallo : m === k ? PALETA.espera : PALETA.leche;
      this.guardar(texto(this, x0 + anchoFila + p * anchoCol + anchoCol / 2, yM + 7, `${m}/${k}`, {
        fontSize: '8px',
        color: hex(color),
        fontFamily: MONO
      }).setOrigin(0.5, 0));
    }

    const ultimo = red.ultimoDisparo();
    const yU = yM + 28;
    this.guardar(texto(this, x0, yU, ultimo ? `Último disparo: ${ultimo.transicion}  ·  u = [${ultimo.u.join(', ')}]` : 'Último disparo: aún no hay disparos', {
      fontSize: '9px',
      color: hex(PALETA.texto),
      fontFamily: MONO
    }));
    if (ultimo) {
      const ti = red.idxTransicion.get(ultimo.transicion);
      const ecuacion = ultimo.antes
        .map((v, p) => `${v}${red.A[ti][p] >= 0 ? '+' : ''}${red.A[ti][p]}=${ultimo.despues[p]}`)
        .join('  ');
      this.guardar(texto(this, x0, yU + 18, `M_k = M_{k−1} + A^T·u_k  →  ${ecuacion}`, {
        fontSize: '8px',
        color: hex(PALETA.textoSuave),
        fontFamily: MONO,
        wordWrap: { width: 840 }
      }));
    }

    this.guardar(texto(this, x0, yU + 44, 'Probar disparo (sin aplicarlo):', {
      fontSize: '9px',
      color: hex(PALETA.acento)
    }));
    red.transiciones.forEach((t, i) => {
      const b = boton(this, x0 + 70 + i * 128, yU + 68, 120, 24, t.id.replace('t_', ''), () => this.probar(t.id), {
        color: red.habilitada(t.id) ? PALETA.panelBorde : PALETA.metalOscuro,
        hover: PALETA.operacion,
        fontSize: '8px'
      });
      this.guardar(b.fondo);
      this.guardar(b.label);
    });
    this.resultadoTexto = this.guardar(texto(this, x0, yU + 102, this.resultadoPrueba || 'Selecciona una transición para ver el marcado resultante.', {
      fontSize: '9px',
      color: hex(PALETA.textoSuave),
      fontFamily: MONO,
      wordWrap: { width: 840 }
    }));
    const conflictos = red.conflictos();
    this.guardar(texto(this, x0, yU + 124, `Habilitadas: ${red.habilitadas().join(', ') || 'ninguna'}   ·   Conflictos: ${conflictos.length ? conflictos.map((c) => `${c.a} vs ${c.b} por ${c.lugar}`).join(' · ') : 'ninguno'}`, {
      fontSize: '8px',
      color: hex(PALETA.textoSuave),
      wordWrap: { width: 840 }
    }));
  }

  probar(tid) {
    const red = this.sim.red;
    const m2 = red.resultado(tid);
    if (m2) {
      this.resultadoPrueba = `M' (${tid}) = [${m2.join(', ')}]  ·  habilitada y dentro de capacidades.`;
    } else {
      this.resultadoPrueba = `M' (${tid}) no es válido: ${red.razonNoHabilitada(tid).texto}`;
    }
    this.dibujar();
  }

  dibujarArbol() {
    const red = this.sim.red;
    const radio = explorar(red, red.M, 4, 600);
    const inicial = red.marcadoInicial();
    const grafo = grafoAlcanzabilidad(red, inicial, 20000);
    const x0 = 46;
    const y0 = 140;

    this.guardar(texto(this, x0, y0, `Marcados alcanzables desde M0: ${grafo.total}${grafo.completo ? '' : ' (truncado)'}  ·  muertos: ${grafo.muertos.length}  ·  red acotada: sin ω  ·  explorados desde M actual (4 niveles): ${radio.nodos.length}`, {
      fontSize: '9px',
      color: hex(PALETA.texto),
      wordWrap: { width: 860 }
    }));
    this.guardar(texto(this, x0, y0 + 20, `M0 actual = [${red.M.join(', ')}]   ·   monitor Cupo_frio: ${red.monitorActivo ? 'ON (146 marcados, 0 muertos)' : 'OFF (160 marcados, 1 muerto)'}`, {
      fontSize: '9px',
      color: hex(red.monitorActivo ? PALETA.operacion : PALETA.espera),
      fontFamily: MONO,
      wordWrap: { width: 860 }
    }));

    const g = this.guardar(this.add.graphics());
    const niveles = new Map();
    for (const n of radio.nodos) {
      if (!niveles.has(n.nivel)) niveles.set(n.nivel, []);
      niveles.get(n.nivel).push(n);
    }
    const posiciones = new Map();
    const maxNivel = Math.max(0, ...radio.nodos.map((n) => n.nivel));
    const alto = 300 / Math.max(1, maxNivel + 1);
    for (const [nivel, lista] of niveles) {
      lista.forEach((n, i) => {
        const x = 90 + ((i + 0.5) / lista.length) * 800;
        const y = y0 + 60 + nivel * Math.min(60, alto);
        posiciones.set(n.id, { x, y, n });
      });
    }
    for (const e of radio.aristas) {
      const a = posiciones.get(e.de);
      const b = posiciones.get(e.a);
      if (!a || !b) continue;
      g.lineStyle(1.6, PALETA.textoSuave, 0.48);
      g.lineBetween(a.x, a.y + 4, b.x, b.y - 4);
    }
    for (const [, p] of posiciones) {
      const muerto = p.n.muerto;
      g.fillStyle(muerto ? PALETA.fallo : p.n.id === 'M0' ? PALETA.acento : PALETA.metal, 0.95);
      g.fillCircle(p.x, p.y, p.n.id === 'M0' ? 7 : 5);
      if (muerto) {
        g.lineStyle(1.5, PALETA.fallo, 0.9);
        g.strokeCircle(p.x, p.y, 8);
      }
    }

    const muertos = radio.muertos.slice(0, 4);
    this.guardar(texto(this, x0, y0 + 310, muertos.length
      ? `Marcados muertos alcanzables (≤4 niveles): ${muertos.map((m) => `[${m.marcado.join(',')}]`).join(' · ')}`
      : 'No hay marcados muertos en 4 niveles desde el marcado actual.', {
      fontSize: '8px',
      color: hex(muertos.length ? PALETA.fallo : PALETA.operacion),
      fontFamily: MONO,
      wordWrap: { width: 860 }
    }));
    this.guardar(texto(this, x0, y0 + 330, 'Verde: marcado actual · rojo: marcado muerto · el inspector usa la red con el monitor activo o desactivado según el juego.', {
      fontSize: '8px',
      color: hex(PALETA.textoSuave)
    }));
  }

  cerrar() {
    this.scene.setVisible(true, 'HUDJuego');
    this.scene.resume('HUDJuego');
    this.scene.resume('Planta');
    this.scene.stop();
  }
}

class Resultados extends Phaser.Scene {
  constructor() {
    super('Resultados');
  }

  init(data) {
    this.sim = data.simulador;
    this.datos = data.data;
    this.resumen = this.datos.resumen;
  }

  create() {
    this.scene.stop('HUDMaquina');
    this.scene.stop('Inspector');
    if (this.scene.isActive('HUDJuego')) {
      this.scene.setVisible(false, 'HUDJuego');
      this.scene.pause('HUDJuego');
    }

    this.add.rectangle(0, 0, 960, 540, 0x000000, 0.58).setOrigin(0).setInteractive();
    panel(this, 80, 30, 800, 480);

    const deadlock = this.datos.motivo === 'deadlock';
    const exito = this.datos.exito;
    const colorTitulo = deadlock ? PALETA.fallo : exito ? PALETA.operacion : PALETA.espera;

    texto(this, 110, 48, deadlock ? 'GAME OVER POR INTERBLOQUEO' : exito ? 'TURNO COMPLETADO · VICTORIA' : 'TURNO COMPLETADO', {
      fontSize: '24px',
      color: hex(colorTitulo),
      fontStyle: 'bold'
    });
    texto(this, 110, 80, deadlock
      ? 'El marcado actual no habilita ninguna transición: espera circular entre vapor, frío y cuarto frío.'
      : exito
        ? 'La planta cumplió la meta de producción sin deadlock.'
        : 'El turno terminó; no se alcanzaron los 6 lotes embotellados.', {
      fontSize: '10px',
      color: hex(PALETA.textoSuave),
      wordWrap: { width: 740 }
    });

    // Bloque izquierdo: puntaje y estadísticas
    texto(this, 110, 110, 'PUNTAJE', { fontSize: '10px', color: hex(PALETA.textoSuave) });
    texto(this, 110, 124, separar(this.resumen.puntuacion), {
      fontSize: '34px',
      color: hex(PALETA.acento),
      fontFamily: MONO,
      fontStyle: 'bold'
    });
    const e = this.resumen.estadisticas;
    const filas = [
      ['Lotes embotellados', `${e.botellas}  (meta ${6})`],
      ['Fallos de máquina', String(e.fallos)],
      ['Reparaciones CIP', `${e.reparaciones} válidas · ${e.reparacionesFallidas} inválidas`],
      ['Intentos bloqueados', String(e.intentosBloqueados)],
      ['Desbordes del silo', String(e.desbordes)],
      ['Deadlocks evitados', String(e.deadlocksEvitados)],
      ['Tiempo de simulación', `${formatoTiempo(this.resumen.tiempo)} / 03:00`]
    ];
    filas.forEach(([k, v], i) => {
      texto(this, 110, 180 + i * 24, k, { fontSize: '10px', color: hex(PALETA.textoSuave) });
      texto(this, 300, 180 + i * 24, v, { fontSize: '10px', color: hex(PALETA.texto) });
    });

    // Bloque derecho: logros
    texto(this, 470, 110, 'LOGROS', { fontSize: '10px', color: hex(PALETA.textoSuave) });
    this.resumen.logros.forEach((l, i) => {
      const y = 128 + i * 33;
      texto(this, 470, y, l.ganado ? '✓' : '○', {
        fontSize: '14px',
        color: hex(l.ganado ? PALETA.operacion : PALETA.textoSuave),
        fontFamily: MONO
      });
      texto(this, 492, y, l.nombre, {
        fontSize: '11px',
        color: hex(l.ganado ? PALETA.leche : PALETA.textoSuave)
      });
      texto(this, 492, y + 13, l.descripcion, {
        fontSize: '8px',
        color: hex(PALETA.textoSuave),
        wordWrap: { width: 330 }
      });
    });

    // Bloque inferior: deadlock o resumen
    if (deadlock) {
      const obj = this.datos.marcadoObj ?? {};
      const marcado = Object.entries(obj)
        .map(([k, v]) => `${k}=${v}`)
        .join(' · ');
      texto(this, 110, 340, 'Marcado muerto', { fontSize: '10px', color: hex(PALETA.fallo) });
      texto(this, 110, 354, `[${marcado}]`, {
        fontSize: '8px',
        color: hex(PALETA.texto),
        fontFamily: MONO,
        wordWrap: { width: 740 }
      });
      texto(this, 110, 378, 'Secuencia de disparos', { fontSize: '10px', color: hex(PALETA.acento) });
      texto(this, 110, 392, `últimos ${Math.min(12, (this.datos.secuencia ?? []).length)}: ${(this.datos.secuencia ?? []).slice(-12).join(' → ') || '—'}`, {
        fontSize: '8px',
        color: hex(PALETA.textoSuave),
        fontFamily: MONO,
        wordWrap: { width: 740 }
      });
      texto(this, 110, 424, `Prevención: ${this.datos.prevencion}`, {
        fontSize: '8px',
        color: hex(PALETA.espera),
        wordWrap: { width: 740 }
      });
    } else {
      texto(this, 110, 340, 'Conformidad con el modelo', { fontSize: '10px', color: hex(PALETA.acento) });
      texto(this, 110, 356, `Cada lote salió por δ y por el disparo de una transición. El monitor Cupo_frio quedó ${this.resumen.monitorActivo ? 'activo' : 'inactivo'}; el radar cerró en ${this.resumen.radar?.color ?? '—'}.`, {
        fontSize: '9px',
        color: hex(PALETA.textoSuave),
        wordWrap: { width: 740 }
      });
      texto(this, 110, 390, `Meta: ${6} lotes · logrados: ${e.botellas} · ${exito ? 'victoria' : 'sin victoria'} · tiempo restante: ${formatoTiempo(this.resumen.tiempoRestante)}`, {
        fontSize: '9px',
        color: hex(PALETA.texto)
      });
      texto(this, 110, 414, 'Prueba el modo de prevención: activa Cupo_frio antes de llenar el cuarto frío y observa el radar.', {
        fontSize: '8px',
        color: hex(PALETA.espera)
      });
    }

    // Botones
    boton(this, 200, 478, 180, 34, 'Jugar otro turno', () => this.otroTurno(), {
      color: PALETA.operacion,
      hover: 0x38b86c,
      fontSize: '11px',
      textoColor: PALETA.leche
    });
    if (deadlock && this.datos.puntoSeguro) {
      boton(this, 420, 478, 220, 34, 'Reintentar desde el último verde', () => this.reintentarSeguro(), {
        color: PALETA.mantenimiento,
        hover: 0x4f92ea,
        fontSize: '10px',
        textoColor: PALETA.leche
      });
    }
    boton(this, 680, 478, 140, 34, 'Volver al título', () => this.volverTitulo(), {
      color: PALETA.metalOscuro,
      hover: PALETA.panelBorde,
      fontSize: '10px'
    });
  }

  otroTurno() {
    this.scene.stop('HUDMaquina');
    this.scene.stop('Inspector');
    this.scene.stop('HUDJuego');
    const planta = this.scene.get('Planta');
    planta.scene.restart();
    this.scene.stop();
  }

  reintentarSeguro() {
    this.scene.stop('HUDMaquina');
    this.scene.stop('Inspector');
    this.scene.setVisible(true, 'HUDJuego');
    this.scene.resume('HUDJuego');
    this.scene.resume('Planta');
    this.sim.reintentarSeguro();
    this.scene.stop();
  }

  volverTitulo() {
    this.scene.stop('HUDMaquina');
    this.scene.stop('Inspector');
    this.scene.stop('HUDJuego');
    this.scene.stop('Planta');
    this.scene.start('Titulo');
    this.scene.stop();
  }
}

// Phaser 4.2.1 se carga por CDN en index.html; aquí se usa el objeto global.
const config = {
  type: Phaser.AUTO,
  width: 960,
  height: 540,
  parent: 'game-container',
  backgroundColor: '#0b1218',
  scale: {
    mode: Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH
  },
  render: {
    antialias: true,
    roundPixels: false
  },
  scene: [Arranque, Titulo, Planta, HUDJuego, HUDMaquina, Inspector, Resultados]
};

// Se expone para depuración en la consola del navegador.
window.game = new Phaser.Game(config);
